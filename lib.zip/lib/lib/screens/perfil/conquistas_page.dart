import 'package:flutter/material.dart';

class ConquistasPage extends StatelessWidget {
  final bool primeiraCorrida;
  final bool conquista10Km;
  final int nivel;

  const ConquistasPage({
    super.key,
    required this.primeiraCorrida,
    required this.conquista10Km,
    required this.nivel,
  });

  Widget conquista(
    String titulo,
    bool desbloqueada,
    IconData icone,
  ) {
    return Card(
      child: ListTile(
        leading: Icon(
          icone,
          color: desbloqueada
              ? Colors.amber
              : Colors.grey,
        ),
        title: Text(titulo),
        subtitle: Text(
          desbloqueada
              ? "Desbloqueada"
              : "Bloqueada",
        ),
        trailing: Icon(
          desbloqueada
              ? Icons.check_circle
              : Icons.lock,
          color: desbloqueada
              ? Colors.green
              : Colors.grey,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Conquistas"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            conquista(
              "Primeira Corrida",
              primeiraCorrida,
              Icons.directions_run,
            ),

            conquista(
              "10 KM Percorridos",
              conquista10Km,
              Icons.emoji_events,
            ),

            conquista(
              "Nível 5",
              nivel >= 5,
              Icons.star,
            ),

            conquista(
              "Nível 10",
              nivel >= 10,
              Icons.workspace_premium,
            ),
          ],
        ),
      ),
    );
  }
}