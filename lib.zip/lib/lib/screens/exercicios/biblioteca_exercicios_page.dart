import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/exercicios/exercicios.dart';
import '../../models/exercicio_model.dart';
import '../../services/storage_service.dart';
import '../../theme/app_theme.dart';

class _ExercicioBuscaIndex {
  final ExercicioModel exercicio;
  final String textoBusca;
  final String categoria;
  final Set<String> musculos;
  final Set<String> equipamentos;
  final Set<String> locais;

  const _ExercicioBuscaIndex({
    required this.exercicio,
    required this.textoBusca,
    required this.categoria,
    required this.musculos,
    required this.equipamentos,
    required this.locais,
  });
}

class BibliotecaExerciciosPage extends StatefulWidget {
  final void Function(ExercicioModel)? onSelecionar;
  final String? categoriaInicial;

  const BibliotecaExerciciosPage({
    super.key,
    this.onSelecionar,
    this.categoriaInicial,
  });

  @override
  State<BibliotecaExerciciosPage> createState() =>
      _BibliotecaExerciciosPageState();
}

class _BibliotecaExerciciosPageState extends State<BibliotecaExerciciosPage> {
  final pesquisaController = TextEditingController();

  Timer? buscaDebounce;
  late final List<_ExercicioBuscaIndex> indiceBusca;
  late final List<String> musculosDisponiveis;
  late final List<String> equipamentosDisponiveis;

  Set<String> favoritosIds = {};
  List<ExercicioModel> exerciciosFiltrados = [];
  String termoBusca = "";
  String termoBuscaNormalizado = "";
  String? musculoSelecionado;
  String? equipamentoSelecionado;
  String? localSelecionado;
  bool apenasFavoritos = false;
  bool carregandoFavoritos = true;

  @override
  void initState() {
    super.initState();
    indiceBusca = bancoExercicios.map(_criarIndice).toList(growable: false);
    musculosDisponiveis = _montarMusculosDisponiveis();
    equipamentosDisponiveis = _montarEquipamentosDisponiveis();
    exerciciosFiltrados = _filtrarExercicios();
    pesquisaController.addListener(_onBuscaAlterada);
    _carregarFavoritos();
  }

  @override
  void dispose() {
    buscaDebounce?.cancel();
    pesquisaController.removeListener(_onBuscaAlterada);
    pesquisaController.dispose();
    super.dispose();
  }

  void _onBuscaAlterada() {
    buscaDebounce?.cancel();
    buscaDebounce = Timer(const Duration(milliseconds: 300), () {
      if (!mounted) return;

      _atualizarFiltros(() {
        termoBusca = pesquisaController.text.trim();
        termoBuscaNormalizado = _normalizar(termoBusca);
      });
    });
  }

  Future<void> _carregarFavoritos() async {
    final favoritos = await StorageService.carregarFavoritosExercicios();

    if (!mounted) return;

    _sincronizarFavoritos(favoritos);

    setState(() {
      favoritosIds = favoritos;
      carregandoFavoritos = false;
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  void _sincronizarFavoritos(Set<String> favoritos) {
    for (final exercicio in bancoExercicios) {
      exercicio.favorito = favoritos.contains(exercicio.id);
    }
  }

  Future<void> _alternarFavorito(ExercicioModel exercicio) async {
    final favoritado = await StorageService.alternarFavoritoExercicio(
      exercicio.id,
    );
    final atualizados = {...favoritosIds};

    if (favoritado) {
      atualizados.add(exercicio.id);
    } else {
      atualizados.remove(exercicio.id);
    }

    _sincronizarFavoritos(atualizados);

    if (!mounted) return;

    setState(() {
      favoritosIds = atualizados;
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  void _atualizarFiltros(VoidCallback atualizar) {
    if (!mounted) return;

    setState(() {
      atualizar();
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  _ExercicioBuscaIndex _criarIndice(ExercicioModel exercicio) {
    return _ExercicioBuscaIndex(
      exercicio: exercicio,
      textoBusca: _textoBusca(exercicio),
      categoria: _normalizar(exercicio.categoria),
      musculos: _musculosDoExercicio(exercicio),
      equipamentos: _equipamentosDoExercicio(exercicio),
      locais: exercicio.locais.map(_normalizar).toSet(),
    );
  }

  List<ExercicioModel> _filtrarExercicios() {
    final busca = termoBuscaNormalizado;
    final categoriaInicial = widget.categoriaInicial == null
        ? null
        : _normalizar(widget.categoriaInicial!);
    final musculo = musculoSelecionado == null
        ? null
        : _normalizar(musculoSelecionado!);
    final equipamento = equipamentoSelecionado == null
        ? null
        : _normalizar(equipamentoSelecionado!);
    final local = localSelecionado == null
        ? null
        : _normalizar(localSelecionado!);

    return indiceBusca
        .where((item) {
          if (categoriaInicial != null && item.categoria != categoriaInicial) {
            return false;
          }

          if (apenasFavoritos && !favoritosIds.contains(item.exercicio.id)) {
            return false;
          }

          if (local != null && !item.locais.contains(local)) {
            return false;
          }

          if (musculo != null && !item.musculos.contains(musculo)) {
            return false;
          }

          if (equipamento != null && !item.equipamentos.contains(equipamento)) {
            return false;
          }

          if (busca.isEmpty) return true;

          return item.textoBusca.contains(busca);
        })
        .map((item) => item.exercicio)
        .toList(growable: false);
  }

  List<String> _montarMusculosDisponiveis() {
    final itens = <String>{};

    for (final exercicio in bancoExercicios) {
      itens.addAll(exercicio.musculos);
      itens.addAll(exercicio.musculosSecundarios);
    }

    return _ordenar(itens);
  }

  List<String> _montarEquipamentosDisponiveis() {
    final itens = <String>{};

    for (final exercicio in bancoExercicios) {
      if (exercicio.equipamentos.isEmpty) {
        itens.add("Peso corporal");
      } else {
        itens.addAll(exercicio.equipamentos);
      }
    }

    return _ordenar(itens);
  }

  Future<void> _abrirDetalhe(ExercicioModel exercicio) async {
    final selecionado = await Navigator.push<ExercicioModel>(
      context,
      MaterialPageRoute(
        builder: (_) => BibliotecaExercicioDetalhePage(
          exercicio: exercicio,
          permitirSelecao: widget.onSelecionar != null,
        ),
      ),
    );

    await _carregarFavoritos();

    if (selecionado != null) {
      _selecionarExercicio(selecionado);
    }
  }

  void _selecionarExercicio(ExercicioModel exercicio) {
    final callback = widget.onSelecionar;
    if (callback == null) return;

    callback(exercicio);
    Navigator.pop(context);
  }

  void _limparFiltros() {
    buscaDebounce?.cancel();
    pesquisaController.removeListener(_onBuscaAlterada);
    pesquisaController.clear();
    pesquisaController.addListener(_onBuscaAlterada);

    _atualizarFiltros(() {
      termoBusca = "";
      termoBuscaNormalizado = "";
      musculoSelecionado = null;
      equipamentoSelecionado = null;
      localSelecionado = null;
      apenasFavoritos = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final horizontal = _horizontalPadding(context);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text("Biblioteca de exercicios")),
      body: RefreshIndicator(
        onRefresh: _carregarFavoritos,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(horizontal, 20, horizontal, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildHero(exerciciosFiltrados.length),
                    const SizedBox(height: 18),
                    _buildBusca(),
                    const SizedBox(height: 16),
                    _buildFiltros(),
                  ],
                ),
              ),
            ),
            if (carregandoFavoritos)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: SliverToBoxAdapter(child: _loadingCard()),
              )
            else if (exerciciosFiltrados.isEmpty)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: SliverToBoxAdapter(child: _estadoVazio()),
              )
            else
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: _buildLista(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHero(int totalFiltrado) {
    return AppGradientCard(
      gradient: AppColors.gradientPrimary,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.black.withAlpha(24),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(
              Icons.fitness_center_rounded,
              color: Colors.black,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "BIBLIOTECA FITIA",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  "$totalFiltrado de ${bancoExercicios.length} exercicios",
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  "Pesquise, filtre e encontre o movimento certo para sua ficha.",
                  style: TextStyle(
                    color: Colors.black87,
                    fontSize: 13,
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBusca() {
    return TextField(
      controller: pesquisaController,
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: "Buscar por nome, musculo, tag ou equipamento",
        prefixIcon: const Icon(Icons.search_rounded),
        suffixIcon: termoBusca.isEmpty
            ? null
            : IconButton(
                onPressed: () => pesquisaController.clear(),
                icon: const Icon(Icons.close_rounded),
                tooltip: "Limpar busca",
              ),
      ),
    );
  }

  Widget _buildFiltros() {
    final filtrosAtivos =
        apenasFavoritos ||
        localSelecionado != null ||
        musculoSelecionado != null ||
        equipamentoSelecionado != null ||
        termoBusca.isNotEmpty;

    return AppGradientCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.tune_rounded, color: AppColors.primary),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  "Filtros",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
              ),
              if (filtrosAtivos)
                TextButton(
                  onPressed: _limparFiltros,
                  child: const Text("Limpar"),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilterChip(
                selected: apenasFavoritos,
                label: const Text("Favoritos"),
                avatar: const Icon(Icons.star_rounded, size: 16),
                onSelected: (value) {
                  _atualizarFiltros(() {
                    apenasFavoritos = value;
                  });
                },
              ),
              _filterChip(
                label: "Casa",
                selected: localSelecionado == "Casa",
                onTap: () => _selecionarLocal("Casa"),
              ),
              _filterChip(
                label: "Academia",
                selected: localSelecionado == "Academia",
                onTap: () => _selecionarLocal("Academia"),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _filtroHorizontal(
            titulo: "Musculo",
            itens: musculosDisponiveis,
            selecionado: musculoSelecionado,
            onSelecionar: (valor) {
              _atualizarFiltros(() {
                musculoSelecionado = musculoSelecionado == valor ? null : valor;
              });
            },
          ),
          const SizedBox(height: 12),
          _filtroHorizontal(
            titulo: "Equipamento",
            itens: equipamentosDisponiveis,
            selecionado: equipamentoSelecionado,
            onSelecionar: (valor) {
              _atualizarFiltros(() {
                equipamentoSelecionado = equipamentoSelecionado == valor
                    ? null
                    : valor;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _filtroHorizontal({
    required String titulo,
    required List<String> itens,
    required String? selecionado,
    required void Function(String valor) onSelecionar,
  }) {
    final visiveis = itens.take(28).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          titulo.toUpperCase(),
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.8,
          ),
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            children: visiveis.map((item) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: _filterChip(
                  label: item,
                  selected: selecionado == item,
                  onTap: () => onSelecionar(item),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _filterChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return ChoiceChip(
      selected: selected,
      label: Text(label),
      onSelected: (_) => onTap(),
      selectedColor: AppColors.primary,
      backgroundColor: AppColors.surfaceVariant,
      labelStyle: TextStyle(
        color: selected ? Colors.black : Colors.white70,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(
        color: selected ? AppColors.primary : const Color(0xFF2A2A2A),
      ),
    );
  }

  Widget _buildLista() {
    return SliverLayoutBuilder(
      builder: (context, constraints) {
        final colunas = constraints.crossAxisExtent >= 920 ? 2 : 1;
        final linhas = (exerciciosFiltrados.length / colunas).ceil();

        return SliverList.builder(
          itemCount: linhas,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _buildLinhaExercicio(index * colunas, colunas),
            );
          },
        );
      },
    );
  }

  Widget _buildLinhaExercicio(int inicio, int colunas) {
    final primeiro = _exercicioCard(exerciciosFiltrados[inicio]);

    if (colunas == 1) return primeiro;

    final segundoIndex = inicio + 1;
    final segundo = segundoIndex < exerciciosFiltrados.length
        ? _exercicioCard(exerciciosFiltrados[segundoIndex])
        : const SizedBox.shrink();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: primeiro),
        const SizedBox(width: 12),
        Expanded(child: segundo),
      ],
    );
  }

  Widget _exercicioCard(ExercicioModel exercicio) {
    final favorito = favoritosIds.contains(exercicio.id);
    final equipamento = exercicio.equipamentos.isEmpty
        ? "Peso corporal"
        : exercicio.equipamentos.first;
    final locais = exercicio.locais.isEmpty
        ? "Local livre"
        : exercicio.locais.join(" / ");

    return GestureDetector(
      onTap: () => _abrirDetalhe(exercicio),
      child: AppGradientCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(26),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Text(
                      exercicio.nome.isEmpty ? "?" : exercicio.nome[0],
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exercicio.nome,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        "${exercicio.categoria} • ${exercicio.dificuldade}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 38,
                  height: 38,
                  child: IconButton(
                    onPressed: () => _alternarFavorito(exercicio),
                    tooltip: favorito ? "Remover favorito" : "Favoritar",
                    icon: Icon(
                      favorito ? Icons.star_rounded : Icons.star_border_rounded,
                    ),
                    color: favorito ? AppColors.accent2 : Colors.white54,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _miniChip(equipamento),
                _miniChip(locais),
                if (exercicio.caloriasHora > 0)
                  _miniChip("${exercicio.caloriasHora} kcal/h"),
              ],
            ),
            if (exercicio.musculos.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                exercicio.musculos.take(3).join(" • "),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
            if (widget.onSelecionar != null) ...[
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => _selecionarExercicio(exercicio),
                icon: const Icon(Icons.add_rounded),
                label: const Text("Adicionar"),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _miniChip(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Text(
        texto,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _estadoVazio() {
    return AppGradientCard(
      child: Column(
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(
              Icons.search_off_rounded,
              color: AppColors.primary,
              size: 30,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            "Nenhum exercicio encontrado",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Ajuste a busca ou remova alguns filtros para ampliar os resultados.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, height: 1.4),
          ),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: _limparFiltros,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text("Limpar filtros"),
          ),
        ],
      ),
    );
  }

  Widget _loadingCard() {
    return AppGradientCard(
      child: Row(
        children: const [
          SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Text(
              "Carregando biblioteca...",
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  void _selecionarLocal(String local) {
    _atualizarFiltros(() {
      localSelecionado = localSelecionado == local ? null : local;
    });
  }

  Set<String> _musculosDoExercicio(ExercicioModel exercicio) {
    return {
      ...exercicio.musculos.map(_normalizar),
      ...exercicio.musculosSecundarios.map(_normalizar),
    };
  }

  Set<String> _equipamentosDoExercicio(ExercicioModel exercicio) {
    if (exercicio.equipamentos.isEmpty) {
      return {_normalizar("Peso corporal")};
    }

    return exercicio.equipamentos.map(_normalizar).toSet();
  }

  String _textoBusca(ExercicioModel exercicio) {
    return [
      exercicio.nome,
      exercicio.categoria,
      exercicio.descricao,
      exercicio.comoExecutar,
      exercicio.dificuldade,
      exercicio.objetivo,
      ...exercicio.musculos,
      ...exercicio.musculosSecundarios,
      ...exercicio.equipamentos,
      ...exercicio.locais,
      ...exercicio.tags,
    ].map(_normalizar).join(" ");
  }

  List<String> _ordenar(Set<String> itens) {
    return itens.where((item) => item.trim().isNotEmpty).toList()
      ..sort((a, b) => _normalizar(a).compareTo(_normalizar(b)));
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

class BibliotecaExercicioDetalhePage extends StatefulWidget {
  final ExercicioModel exercicio;
  final bool permitirSelecao;

  const BibliotecaExercicioDetalhePage({
    super.key,
    required this.exercicio,
    this.permitirSelecao = false,
  });

  @override
  State<BibliotecaExercicioDetalhePage> createState() =>
      _BibliotecaExercicioDetalhePageState();
}

class _BibliotecaExercicioDetalhePageState
    extends State<BibliotecaExercicioDetalhePage> {
  bool favorito = false;
  bool carregandoFavorito = true;

  ExercicioModel get exercicio => widget.exercicio;

  @override
  void initState() {
    super.initState();
    _carregarFavorito();
  }

  Future<void> _carregarFavorito() async {
    final favoritos = await StorageService.carregarFavoritosExercicios();

    if (!mounted) return;

    setState(() {
      favorito = favoritos.contains(exercicio.id);
      exercicio.favorito = favorito;
      carregandoFavorito = false;
    });
  }

  Future<void> _alternarFavorito() async {
    final novoEstado = await StorageService.alternarFavoritoExercicio(
      exercicio.id,
    );

    if (!mounted) return;

    setState(() {
      favorito = novoEstado;
      exercicio.favorito = novoEstado;
    });
  }

  List<ExercicioModel> get semelhantes {
    final candidatos = bancoExercicios.where((item) {
      if (item.id == exercicio.id) return false;

      return _scoreSemelhanca(item) > 0;
    }).toList();

    candidatos.sort(
      (a, b) => _scoreSemelhanca(b).compareTo(_scoreSemelhanca(a)),
    );

    return candidatos.take(6).toList();
  }

  int _scoreSemelhanca(ExercicioModel candidato) {
    var score = 0;

    if (_normalizar(candidato.categoria) == _normalizar(exercicio.categoria)) {
      score += 3;
    }

    score += _intersecoes(
      _musculosDoExercicio(candidato),
      _musculosDoExercicio(exercicio),
    );

    score += _intersecoes(
      candidato.equipamentos.map(_normalizar).toSet(),
      exercicio.equipamentos.map(_normalizar).toSet(),
    );

    return score;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(exercicio.nome)),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(
          _horizontalPadding(context),
          20,
          _horizontalPadding(context),
          32,
        ),
        children: [
          _topoDetalhe(),
          const SizedBox(height: 16),
          _acoes(),
          const SizedBox(height: 16),
          _secaoTexto(
            titulo: "Execucao",
            texto: exercicio.comoExecutar.isEmpty
                ? "Instrucoes ainda nao cadastradas."
                : exercicio.comoExecutar,
            icon: Icons.playlist_add_check_rounded,
          ),
          _secaoTexto(
            titulo: "Descricao",
            texto: exercicio.descricao.isEmpty
                ? "Descricao ainda nao cadastrada."
                : exercicio.descricao,
            icon: Icons.notes_rounded,
          ),
          _chips(
            titulo: "Musculos principais",
            itens: exercicio.musculos,
            vazio: "Musculos principais nao cadastrados.",
            icon: Icons.accessibility_new_rounded,
          ),
          _chips(
            titulo: "Musculos secundarios",
            itens: exercicio.musculosSecundarios,
            vazio: "Musculos secundarios nao cadastrados.",
            icon: Icons.hub_rounded,
          ),
          _chips(
            titulo: "Equipamentos",
            itens: exercicio.equipamentos.isEmpty
                ? const ["Peso corporal"]
                : exercicio.equipamentos,
            vazio: "Equipamentos nao cadastrados.",
            icon: Icons.fitness_center_rounded,
          ),
          _chips(
            titulo: "Dificuldade e locais",
            itens: [
              exercicio.dificuldade,
              exercicio.objetivo,
              ...exercicio.locais,
            ],
            vazio: "Dados adicionais nao cadastrados.",
            icon: Icons.tune_rounded,
          ),
          _semelhantesCard(),
        ],
      ),
    );
  }

  Widget _topoDetalhe() {
    return AppGradientCard(
      gradient: AppColors.gradientPrimary,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              color: Colors.black.withAlpha(24),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Text(
                exercicio.nome.isEmpty ? "?" : exercicio.nome[0],
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "DETALHE DO EXERCICIO",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  exercicio.nome,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _topoChip(exercicio.categoria),
                    _topoChip(exercicio.dificuldade),
                    if (exercicio.caloriasHora > 0)
                      _topoChip("${exercicio.caloriasHora} kcal/h"),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _acoes() {
    final favoritoLabel = favorito ? "Remover favorito" : "Favoritar";

    return LayoutBuilder(
      builder: (context, constraints) {
        final ladoALado = widget.permitirSelecao && constraints.maxWidth >= 560;
        final favoritoButton = OutlinedButton.icon(
          onPressed: carregandoFavorito ? null : _alternarFavorito,
          icon: Icon(favorito ? Icons.star_rounded : Icons.star_border_rounded),
          label: Text(favoritoLabel),
        );
        final adicionarButton = ElevatedButton.icon(
          onPressed: () => Navigator.pop(context, exercicio),
          icon: const Icon(Icons.add_rounded),
          label: const Text("Adicionar a ficha"),
        );

        if (!widget.permitirSelecao) return favoritoButton;

        if (!ladoALado) {
          return Column(
            children: [
              adicionarButton,
              const SizedBox(height: 10),
              favoritoButton,
            ],
          );
        }

        return Row(
          children: [
            Expanded(child: adicionarButton),
            const SizedBox(width: 12),
            Expanded(child: favoritoButton),
          ],
        );
      },
    );
  }

  Widget _secaoTexto({
    required String titulo,
    required String texto,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AppGradientCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _secaoTitulo(titulo, icon),
            const SizedBox(height: 12),
            Text(
              texto,
              style: const TextStyle(color: Colors.white70, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chips({
    required String titulo,
    required List<String> itens,
    required String vazio,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AppGradientCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _secaoTitulo(titulo, icon),
            const SizedBox(height: 12),
            if (itens.isEmpty)
              Text(
                vazio,
                style: const TextStyle(color: Colors.white70, height: 1.4),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: itens.map(_chipEscuro).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _semelhantesCard() {
    final lista = semelhantes;

    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _secaoTitulo("Exercicios semelhantes", Icons.auto_awesome_rounded),
          const SizedBox(height: 12),
          if (lista.isEmpty)
            const Text(
              "Nenhum exercicio semelhante encontrado.",
              style: TextStyle(color: Colors.white70),
            )
          else
            Column(
              children: lista.map((item) {
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF2A2A2A)),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.fitness_center_rounded,
                        color: AppColors.primary,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item.nome,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              "${item.categoria} • ${item.dificuldade}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _secaoTitulo(String titulo, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primary, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            titulo.toUpperCase(),
            style: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
      ],
    );
  }

  Widget _chipEscuro(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _topoChip(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(24),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: Colors.black87,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Set<String> _musculosDoExercicio(ExercicioModel exercicio) {
    return {
      ...exercicio.musculos.map(_normalizar),
      ...exercicio.musculosSecundarios.map(_normalizar),
    };
  }

  int _intersecoes(Set<String> a, Set<String> b) {
    return a.where(b.contains).length;
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

String _normalizar(String texto) {
  var valor = texto.toLowerCase().trim();
  final substituicoes = {
    "á": "a",
    "à": "a",
    "â": "a",
    "ã": "a",
    "ä": "a",
    "é": "e",
    "ê": "e",
    "è": "e",
    "ë": "e",
    "í": "i",
    "ì": "i",
    "î": "i",
    "ï": "i",
    "ó": "o",
    "ò": "o",
    "ô": "o",
    "õ": "o",
    "ö": "o",
    "ú": "u",
    "ù": "u",
    "û": "u",
    "ü": "u",
    "ç": "c",
  };

  for (final entrada in substituicoes.entries) {
    valor = valor.replaceAll(entrada.key, entrada.value);
  }

  return valor;
}
