import 'package:flutter/material.dart';

import '../../models/historico_treino_model.dart';
import '../../models/treino_model.dart';
import '../../services/ia_evolutiva_service.dart';
import '../../services/storage_service.dart';
import '../../services/treino_service.dart';
import '../../theme/app_theme.dart';
import '../ai_workout_page.dart';
import '../treinos/criar_treino_page.dart';
import '../treinos/treinos_page.dart';

class _TreinoDoDiaSelecao {
  final TreinoModel? treino;
  final bool diaDeDescanso;
  final bool treinoConcluidoHoje;
  final bool todosTreinosConcluidosHoje;
  final String titulo;
  final String descricao;
  final String motivo;

  const _TreinoDoDiaSelecao({
    required this.treino,
    required this.diaDeDescanso,
    required this.treinoConcluidoHoje,
    required this.todosTreinosConcluidosHoje,
    required this.titulo,
    required this.descricao,
    required this.motivo,
  });
}

class _StreakResumo {
  final int atual;
  final int melhor;
  final bool treinouHoje;

  const _StreakResumo({
    required this.atual,
    required this.melhor,
    required this.treinouHoje,
  });
}

class HomePage extends StatefulWidget {
  final String nome;
  final double distancia;
  final int passos;
  final int xp;
  final int nivel;
  final Future<void> Function()? onXpAtualizado;

  const HomePage({
    super.key,
    required this.nome,
    required this.distancia,
    required this.passos,
    required this.xp,
    required this.nivel,
    this.onXpAtualizado,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final treinoService = TreinoService.instance;

  bool carregandoTreinos = true;
  bool atualizandoDadosHoje = false;
  bool treinoConcluidoHoje = false;
  List<HistoricoTreinoModel> historicoTreinos = [];
  IaEvolutivaRecomendacao? recomendacao;

  @override
  void initState() {
    super.initState();
    treinoService.addListener(_onTreinosAtualizados);
    _carregarDadosHoje();
  }

  @override
  void dispose() {
    treinoService.removeListener(_onTreinosAtualizados);
    super.dispose();
  }

  void _onTreinosAtualizados() {
    if (!mounted) return;
    _carregarDadosHoje();
  }

  Future<void> _carregarDadosHoje() async {
    if (atualizandoDadosHoje) return;

    atualizandoDadosHoje = true;

    try {
      final historico = await StorageService.carregarHistoricoTreinos();

      final recomendacaoAtual = await IaEvolutivaService.instance
          .gerarRecomendacao(
            treinosDisponiveis: treinoService.treinos,
            historico: historico,
            xpAtual: widget.xp,
            nivelAtual: widget.nivel,
          );

      final agora = DateTime.now();

      final concluiuHoje = historico.any((item) {
        final data = item.dataHora.toLocal();

        return data.year == agora.year &&
            data.month == agora.month &&
            data.day == agora.day;
      });

      if (!mounted) return;

      setState(() {
        treinoConcluidoHoje = concluiuHoje;
        historicoTreinos = historico;
        recomendacao = recomendacaoAtual;
        carregandoTreinos = false;
      });
    } finally {
      atualizandoDadosHoje = false;
    }
  }

  TreinoModel? get treinoHoje {
    return selecionarTreinoDoDia(treinoService.treinos, historicoTreinos);
  }

  TreinoModel? selecionarTreinoDoDia(
    List<TreinoModel> treinos,
    List<HistoricoTreinoModel> historico,
  ) {
    return _selecionarTreinoDoDiaDetalhado(treinos, historico).treino;
  }

  _TreinoDoDiaSelecao _selecionarTreinoDoDiaDetalhado(
    List<TreinoModel> treinos,
    List<HistoricoTreinoModel>? historico,
  ) {
    if (treinos.isEmpty) {
      return const _TreinoDoDiaSelecao(
        treino: null,
        diaDeDescanso: false,
        treinoConcluidoHoje: false,
        todosTreinosConcluidosHoje: false,
        titulo: 'Nenhum treino criado ainda',
        descricao: 'Monte uma ficha manual ou gere uma com IA.',
        motivo: 'Nenhum treino disponível.',
      );
    }

    final concluidosHoje = _nomesTreinosConcluidosHoje(historico);
    final todosConcluidosHoje = treinos.every(
      (treino) => _foiConcluidoHoje(treino, concluidosHoje),
    );

    if (todosConcluidosHoje) {
      final treino = treinos.first;

      return _TreinoDoDiaSelecao(
        treino: treino,
        diaDeDescanso: false,
        treinoConcluidoHoje: true,
        todosTreinosConcluidosHoje: true,
        titulo: 'Treino do dia concluído',
        descricao:
            'Você já concluiu todos os treinos disponíveis hoje. Priorize recuperação.',
        motivo:
            'Todos os treinos disponíveis já aparecem no histórico de hoje.',
      );
    }

    final abc = _treinosPorLetra(treinos);
    if (abc.length >= 3) {
      return _selecionarTreinoAbc(treinos, abc, concluidosHoje);
    }

    final pushPullLegs = _treinosPushPullLegs(treinos);
    if (pushPullLegs.length >= 3) {
      return _selecionarTreinoPushPullLegs(
        treinos,
        pushPullLegs,
        concluidosHoje,
      );
    }

    final fullBody = _treinosFullBody(treinos);
    if (fullBody.isNotEmpty) {
      return _selecionarTreinoFullBody(treinos, fullBody, concluidosHoje);
    }

    final treino = _primeiroNaoConcluidoHoje(treinos, concluidosHoje);

    if (treino != null) {
      return _TreinoDoDiaSelecao(
        treino: treino,
        diaDeDescanso: false,
        treinoConcluidoHoje: false,
        todosTreinosConcluidosHoje: false,
        titulo: treino.nome,
        descricao: 'Primeiro treino disponível ainda não concluído hoje.',
        motivo: 'Nenhuma divisão semanal foi detectada pelo nome dos treinos.',
      );
    }

    return _TreinoDoDiaSelecao(
      treino: treinos.first,
      diaDeDescanso: false,
      treinoConcluidoHoje: true,
      todosTreinosConcluidosHoje: true,
      titulo: 'Treino do dia concluído',
      descricao: 'Você já concluiu os treinos disponíveis hoje.',
      motivo: 'Não há treino pendente para hoje.',
    );
  }

  _TreinoDoDiaSelecao _selecionarTreinoAbc(
    List<TreinoModel> treinos,
    Map<String, TreinoModel> porLetra,
    Set<String> concluidosHoje,
  ) {
    final weekday = DateTime.now().weekday;
    String? letra;
    var diaDeDescanso = false;

    switch (weekday) {
      case DateTime.monday:
        letra = 'a';
        break;
      case DateTime.tuesday:
        letra = 'b';
        break;
      case DateTime.wednesday:
        letra = 'c';
        break;
      case DateTime.thursday:
        letra = porLetra.containsKey('d') ? 'd' : null;
        diaDeDescanso = letra == null;
        break;
      case DateTime.friday:
        letra = porLetra.containsKey('e') ? 'e' : 'a';
        break;
      case DateTime.saturday:
        letra = null;
        break;
      case DateTime.sunday:
        diaDeDescanso = true;
        break;
    }

    final treinoAlvo = letra == null ? null : porLetra[letra];
    final treinoPendente =
        treinoAlvo != null && !_foiConcluidoHoje(treinoAlvo, concluidosHoje)
        ? treinoAlvo
        : _primeiroNaoConcluidoHoje(_ordenarAbc(treinos), concluidosHoje);

    if (diaDeDescanso) {
      final treinoRecuperacao =
          _treinoRecuperacao(treinos, concluidosHoje) ?? treinoPendente;

      return _TreinoDoDiaSelecao(
        treino: treinoRecuperacao,
        diaDeDescanso: true,
        treinoConcluidoHoje: treinoRecuperacao == null
            ? false
            : _foiConcluidoHoje(treinoRecuperacao, concluidosHoje),
        todosTreinosConcluidosHoje: false,
        titulo: 'Dia de recuperação',
        descricao:
            'A divisão não prevê treino pesado hoje. Foque em recuperação ou movimento leve.',
        motivo: 'Divisão ABC detectada e dia atual sem grupo principal claro.',
      );
    }

    return _selecaoComFallback(
      treino: treinoPendente,
      treinos: treinos,
      concluidosHoje: concluidosHoje,
      motivo: 'Divisão ABC/ABCD/ABCDE detectada pelo nome dos treinos.',
    );
  }

  _TreinoDoDiaSelecao _selecionarTreinoPushPullLegs(
    List<TreinoModel> treinos,
    Map<String, TreinoModel> divisao,
    Set<String> concluidosHoje,
  ) {
    final weekday = DateTime.now().weekday;
    String? chave;
    var diaDeDescanso = false;

    switch (weekday) {
      case DateTime.monday:
        chave = 'push';
        break;
      case DateTime.tuesday:
        chave = 'pull';
        break;
      case DateTime.wednesday:
        chave = 'legs';
        break;
      case DateTime.thursday:
        diaDeDescanso = true;
        break;
      case DateTime.friday:
        chave = 'push';
        break;
      case DateTime.saturday:
        chave = divisao.containsKey('pull') ? 'pull' : 'legs';
        break;
      case DateTime.sunday:
        diaDeDescanso = true;
        break;
    }

    final treinoAlvo = chave == null ? null : divisao[chave];
    final ordem = [
      if (divisao['push'] != null) divisao['push']!,
      if (divisao['pull'] != null) divisao['pull']!,
      if (divisao['legs'] != null) divisao['legs']!,
    ];
    final treinoPendente =
        treinoAlvo != null && !_foiConcluidoHoje(treinoAlvo, concluidosHoje)
        ? treinoAlvo
        : _primeiroNaoConcluidoHoje(ordem, concluidosHoje);

    if (diaDeDescanso) {
      final treinoRecuperacao =
          _treinoRecuperacao(treinos, concluidosHoje) ??
          (weekday == DateTime.thursday ? treinoPendente : null);

      return _TreinoDoDiaSelecao(
        treino: treinoRecuperacao,
        diaDeDescanso: true,
        treinoConcluidoHoje: treinoRecuperacao == null
            ? false
            : _foiConcluidoHoje(treinoRecuperacao, concluidosHoje),
        todosTreinosConcluidosHoje: false,
        titulo: 'Dia de recuperação',
        descricao:
            'A divisão Push Pull Legs indica recuperação hoje. Se quiser, faça algo leve.',
        motivo: 'Divisão Push Pull Legs detectada.',
      );
    }

    return _selecaoComFallback(
      treino: treinoPendente,
      treinos: treinos,
      concluidosHoje: concluidosHoje,
      motivo: 'Divisão Push Pull Legs detectada pelo nome dos treinos.',
    );
  }

  _TreinoDoDiaSelecao _selecionarTreinoFullBody(
    List<TreinoModel> treinos,
    List<TreinoModel> fullBody,
    Set<String> concluidosHoje,
  ) {
    final weekday = DateTime.now().weekday;
    final diaDeTreino =
        weekday == DateTime.monday ||
        weekday == DateTime.wednesday ||
        weekday == DateTime.friday;

    if (!diaDeTreino) {
      final recuperacao = _treinoRecuperacao(treinos, concluidosHoje);

      return _TreinoDoDiaSelecao(
        treino: recuperacao,
        diaDeDescanso: true,
        treinoConcluidoHoje: recuperacao == null
            ? false
            : _foiConcluidoHoje(recuperacao, concluidosHoje),
        todosTreinosConcluidosHoje: false,
        titulo: 'Dia de recuperação',
        descricao:
            'A ficha Full Body costuma render melhor com recuperação entre sessões.',
        motivo: 'Divisão Full Body detectada.',
      );
    }

    final treino = _primeiroNaoConcluidoHoje(fullBody, concluidosHoje);

    return _selecaoComFallback(
      treino: treino,
      treinos: fullBody,
      concluidosHoje: concluidosHoje,
      motivo: 'Divisão Full Body detectada para segunda, quarta e sexta.',
    );
  }

  _TreinoDoDiaSelecao _selecaoComFallback({
    required TreinoModel? treino,
    required List<TreinoModel> treinos,
    required Set<String> concluidosHoje,
    required String motivo,
  }) {
    if (treino != null) {
      final concluido = _foiConcluidoHoje(treino, concluidosHoje);

      return _TreinoDoDiaSelecao(
        treino: treino,
        diaDeDescanso: false,
        treinoConcluidoHoje: concluido,
        todosTreinosConcluidosHoje: false,
        titulo: concluido ? 'Treino do dia concluído' : treino.nome,
        descricao: concluido
            ? 'Você já concluiu esse treino hoje.'
            : 'Treino selecionado automaticamente para hoje.',
        motivo: motivo,
      );
    }

    final fallback = treinos.isEmpty ? null : treinos.first;

    return _TreinoDoDiaSelecao(
      treino: fallback,
      diaDeDescanso: false,
      treinoConcluidoHoje: fallback == null
          ? false
          : _foiConcluidoHoje(fallback, concluidosHoje),
      todosTreinosConcluidosHoje: true,
      titulo: 'Treino do dia concluído',
      descricao: 'Você já concluiu os treinos previstos para hoje.',
      motivo: motivo,
    );
  }

  Set<String> _nomesTreinosConcluidosHoje(
    List<HistoricoTreinoModel>? historico,
  ) {
    final agora = DateTime.now();
    final listaHistorico = historico ?? <HistoricoTreinoModel>[];

    return listaHistorico
        .where((item) {
          final data = item.dataHora.toLocal();

          return data.year == agora.year &&
              data.month == agora.month &&
              data.day == agora.day;
        })
        .map((item) => _normalizar(item.nomeTreino))
        .toSet();
  }

  bool _foiConcluidoHoje(TreinoModel treino, Set<String> concluidosHoje) {
    return concluidosHoje.contains(_normalizar(treino.nome));
  }

  TreinoModel? _primeiroNaoConcluidoHoje(
    List<TreinoModel> treinos,
    Set<String> concluidosHoje,
  ) {
    for (final treino in treinos) {
      if (!_foiConcluidoHoje(treino, concluidosHoje)) {
        return treino;
      }
    }

    return null;
  }

  Map<String, TreinoModel> _treinosPorLetra(List<TreinoModel> treinos) {
    final porLetra = <String, TreinoModel>{};

    for (final treino in treinos) {
      final nome = _normalizar(treino.nome);

      for (final letra in const ['a', 'b', 'c', 'd', 'e']) {
        if (nome.startsWith('$letra -') || nome.startsWith('$letra ')) {
          porLetra.putIfAbsent(letra, () => treino);
        }
      }
    }

    return porLetra;
  }

  List<TreinoModel> _ordenarAbc(List<TreinoModel> treinos) {
    final porLetra = _treinosPorLetra(treinos);
    final ordenados = <TreinoModel>[];

    for (final letra in const ['a', 'b', 'c', 'd', 'e']) {
      final treino = porLetra[letra];
      if (treino != null) ordenados.add(treino);
    }

    for (final treino in treinos) {
      if (!ordenados.any((item) => item.id == treino.id)) {
        ordenados.add(treino);
      }
    }

    return ordenados;
  }

  Map<String, TreinoModel> _treinosPushPullLegs(List<TreinoModel> treinos) {
    final divisao = <String, TreinoModel>{};

    for (final treino in treinos) {
      final nome = _normalizar(treino.nome);

      if (nome.startsWith('push')) {
        divisao.putIfAbsent('push', () => treino);
      } else if (nome.startsWith('pull')) {
        divisao.putIfAbsent('pull', () => treino);
      } else if (nome.startsWith('legs')) {
        divisao.putIfAbsent('legs', () => treino);
      }
    }

    return divisao;
  }

  List<TreinoModel> _treinosFullBody(List<TreinoModel> treinos) {
    return treinos.where((treino) {
      final texto = _normalizar('${treino.nome} ${treino.descricao}');

      return texto.contains('full body') || texto.contains('corpo inteiro');
    }).toList();
  }

  TreinoModel? _treinoRecuperacao(
    List<TreinoModel> treinos,
    Set<String> concluidosHoje,
  ) {
    final candidatos = treinos.where((treino) {
      if (_foiConcluidoHoje(treino, concluidosHoje)) return false;

      final texto = _normalizar(
        '${treino.nome} ${treino.descricao} ${treino.objetivo} '
        '${treino.exercicios.map((e) => '${e.nome} ${e.categoria} ${e.tags.join(' ')}').join(' ')}',
      );

      return texto.contains('alongamento') ||
          texto.contains('mobilidade') ||
          texto.contains('cardio') ||
          texto.contains('caminhada') ||
          texto.contains('leve');
    }).toList();

    if (candidatos.isEmpty) return null;

    candidatos.sort((a, b) => a.tempoEstimado.compareTo(b.tempoEstimado));

    return candidatos.first;
  }

  String _normalizar(String texto) {
    var valor = texto.toLowerCase().trim();
    final substituicoes = {
      'á': 'a',
      'à': 'a',
      'â': 'a',
      'ã': 'a',
      'é': 'e',
      'ê': 'e',
      'í': 'i',
      'ó': 'o',
      'ô': 'o',
      'õ': 'o',
      'ú': 'u',
      'ü': 'u',
      'ç': 'c',
      'ã¡': 'a',
      'ã ': 'a',
      'ã¢': 'a',
      'ã£': 'a',
      'ã©': 'e',
      'ãª': 'e',
      'ã­': 'i',
      'ã³': 'o',
      'ã´': 'o',
      'ãµ': 'o',
      'ãº': 'u',
      'ã¼': 'u',
      'ã§': 'c',
    };

    for (final entrada in substituicoes.entries) {
      valor = valor.replaceAll(entrada.key, entrada.value);
    }

    return valor;
  }

  _StreakResumo _calcularStreak(List<HistoricoTreinoModel> historico) {
    if (historico.isEmpty) {
      return const _StreakResumo(atual: 0, melhor: 0, treinouHoje: false);
    }

    final diasTreinados = historico
        .map((item) => _chaveData(item.dataHora.toLocal()))
        .toSet();
    final hoje = _somenteData(DateTime.now());
    final ontem = hoje.subtract(const Duration(days: 1));
    final treinouHoje = diasTreinados.contains(_chaveData(hoje));
    final inicioStreak = treinouHoje ? hoje : ontem;
    var streakAtual = 0;
    var cursor = inicioStreak;

    while (diasTreinados.contains(_chaveData(cursor))) {
      streakAtual++;
      cursor = cursor.subtract(const Duration(days: 1));
    }

    final diasOrdenados = diasTreinados.map(_dataDaChave).toList()..sort();
    var melhorStreak = 0;
    var sequencia = 0;
    DateTime? anterior;

    for (final dia in diasOrdenados) {
      if (anterior == null || dia.difference(anterior).inDays == 1) {
        sequencia++;
      } else {
        sequencia = 1;
      }

      if (sequencia > melhorStreak) {
        melhorStreak = sequencia;
      }

      anterior = dia;
    }

    return _StreakResumo(
      atual: streakAtual,
      melhor: melhorStreak,
      treinouHoje: treinouHoje,
    );
  }

  int _treinosNaSemana(List<HistoricoTreinoModel> historico) {
    final inicio = _inicioSemana(DateTime.now());

    return historico.where((item) {
      final data = _somenteData(item.dataHora.toLocal());
      return !data.isBefore(inicio);
    }).length;
  }

  int _xpTreinosNaSemana(List<HistoricoTreinoModel> historico) {
    final inicio = _inicioSemana(DateTime.now());

    return historico
        .where((item) {
          final data = _somenteData(item.dataHora.toLocal());
          return !data.isBefore(inicio);
        })
        .fold<int>(0, (total, item) => total + item.xpGanho);
  }

  DateTime _inicioSemana(DateTime data) {
    final dia = _somenteData(data);
    return dia.subtract(Duration(days: dia.weekday - DateTime.monday));
  }

  DateTime _somenteData(DateTime data) {
    return DateTime(data.year, data.month, data.day);
  }

  String _chaveData(DateTime data) {
    final local = _somenteData(data);
    return '${local.year}-${local.month}-${local.day}';
  }

  DateTime _dataDaChave(String chave) {
    final partes = chave.split('-');
    if (partes.length != 3) {
      return DateTime.fromMillisecondsSinceEpoch(0);
    }

    return DateTime(
      int.tryParse(partes[0]) ?? 0,
      int.tryParse(partes[1]) ?? 1,
      int.tryParse(partes[2]) ?? 1,
    );
  }

  String rankAtual() {
    if (widget.nivel >= 50) return 'Diamante';
    if (widget.nivel >= 30) return 'Platina';
    if (widget.nivel >= 20) return 'Ouro';
    if (widget.nivel >= 10) return 'Prata';
    return 'Bronze';
  }

  String _proximoRank() {
    if (widget.nivel >= 50) return 'Máximo';
    if (widget.nivel >= 30) return 'Diamante (Nv. 50)';
    if (widget.nivel >= 20) return 'Platina (Nv. 30)';
    if (widget.nivel >= 10) return 'Ouro (Nv. 20)';
    return 'Prata (Nv. 10)';
  }

  Color _corRank() {
    if (widget.nivel >= 50) return AppColors.rankDiamante;
    if (widget.nivel >= 30) return AppColors.rankPlatina;
    if (widget.nivel >= 20) return AppColors.rankOuro;
    if (widget.nivel >= 10) return AppColors.rankPrata;
    return AppColors.rankBronze;
  }

  IconData _iconRank() {
    if (widget.nivel >= 50) return Icons.diamond_rounded;
    if (widget.nivel >= 30) return Icons.emoji_events_rounded;
    if (widget.nivel >= 20) return Icons.military_tech_rounded;
    if (widget.nivel >= 10) return Icons.shield_rounded;
    return Icons.workspace_premium_rounded;
  }

  String _saudacao() {
    final hora = DateTime.now().hour;
    if (hora < 12) return 'Bom dia';
    if (hora < 18) return 'Boa tarde';
    return 'Boa noite';
  }

  Future<void> _abrirTreino(TreinoModel treino) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TreinoEmAndamentoPage(
          treino: treino,
          onXpAtualizado: widget.onXpAtualizado,
        ),
      ),
    );

    await widget.onXpAtualizado?.call();
    await _carregarDadosHoje();
  }

  Future<void> _abrirCriarTreino() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CriarTreinoPage()),
    );

    await _carregarDadosHoje();
  }

  Future<void> _abrirGeradorIa() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AIWorkoutPage()),
    );

    await _carregarDadosHoje();
  }

  @override
  Widget build(BuildContext context) {
    final selecaoTreino = _selecionarTreinoDoDiaDetalhado(
      treinoService.treinos,
      historicoTreinos,
    );
    const cardGap = 16.0;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: _buildHeader(context)),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(
              _horizontalPadding(context),
              0,
              _horizontalPadding(context),
              100,
            ),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // 1. Stats rápidos
                _buildStatsRow(context),
                const SizedBox(height: cardGap),
                // 2. Treino de Hoje
                _buildTreinoCard(context, selecaoTreino),
                const SizedBox(height: cardGap),
                // 3. FitIA Recomenda
                _buildRecomendacaoCard(context, selecaoTreino),
                const SizedBox(height: cardGap),
                // 4. Missões de Hoje (consolidado: Meta Diária + Desafios)
                _buildMissoesCard(context),
                const SizedBox(height: cardGap),
                // 5. Streak
                _buildStreakCard(context),
                const SizedBox(height: cardGap),
                // 6. XP/Rank consolidado
                _buildXpRankCard(context),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        _horizontalPadding(context),
        MediaQuery.of(context).padding.top + 20,
        _horizontalPadding(context),
        24,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: const BoxDecoration(
              gradient: AppColors.gradientPrimary,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                widget.nome.isNotEmpty ? widget.nome[0].toUpperCase() : 'U',
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _saudacao(),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                Text(
                  widget.nome,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: AppColors.primary.withAlpha(80)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.bolt, color: AppColors.primary, size: 14),
                const SizedBox(width: 4),
                Text(
                  'Nv. ${widget.nivel}',
                  style: const TextStyle(
                    color: AppColors.primary,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }

  Widget _buildStatsRow(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: AppStatChip(
            label: 'Distância',
            value: '${widget.distancia.toStringAsFixed(2)} km',
            icon: Icons.route_outlined,
            iconColor: AppColors.primary,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: AppStatChip(
            label: 'Passos',
            value: '${widget.passos}',
            icon: Icons.directions_walk_outlined,
            iconColor: AppColors.accent1,
          ),
        ),
      ],
    );
  }

  Widget _buildTreinoCard(BuildContext context, _TreinoDoDiaSelecao selecao) {
    final treino = selecao.treino;

    if (carregandoTreinos && treino == null) {
      return AppGradientCard(
        gradient: AppColors.gradientWorkout,
        child: Row(
          children: const [
            SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            SizedBox(width: 14),
            Expanded(
              child: Text(
                'Buscando seu treino de hoje...',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      );
    }

    if (treino == null) {
      return AppGradientCard(
        gradient: AppColors.gradientWorkout,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _treinoCardHeader(
              context,
              titulo: selecao.titulo,
              subtitulo: selecao.descricao,
              mostrarSeta: !selecao.diaDeDescanso,
            ),
            if (!selecao.diaDeDescanso) ...[
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: _abrirCriarTreino,
                icon: const Icon(Icons.add_rounded),
                label: const Text('Criar treino'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _abrirGeradorIa,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text('Gerar com IA'),
              ),
            ],
          ],
        ),
      );
    }

    final titulo = selecao.diaDeDescanso
        ? 'Dia de recuperação'
        : selecao.treinoConcluidoHoje
        ? 'Treino do dia concluído'
        : treino.nome;
    final subtitulo = selecao.diaDeDescanso
        ? '${selecao.descricao} Sugestão leve: ${treino.nome}.'
        : selecao.treinoConcluidoHoje
        ? '${selecao.descricao} ${treino.exercicios.length} exercícios • ${treino.tempoEstimado} min'
        : '${treino.exercicios.length} exercícios • ${treino.tempoEstimado} min';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _abrirTreino(treino),
        borderRadius: BorderRadius.circular(20),
        child: AppGradientCard(
          gradient: AppColors.gradientWorkout,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _treinoCardHeader(
                context,
                titulo: titulo,
                subtitulo: subtitulo,
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (selecao.diaDeDescanso)
                    AppChip(label: 'Recuperação', dark: true),
                  if (selecao.treinoConcluidoHoje)
                    AppChip(label: 'Concluído hoje', dark: true),
                  AppChip(label: treino.objetivo, dark: true),
                  AppChip(label: treino.nivel, dark: true),
                  if (treino.criadoPorIA)
                    AppChip(
                      label: 'IA',
                      icon: Icons.auto_awesome_rounded,
                      dark: true,
                    ),
                ],
              ),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () => _abrirTreino(treino),
                icon: Icon(
                  selecao.treinoConcluidoHoje
                      ? Icons.replay_rounded
                      : Icons.play_arrow_rounded,
                ),
                label: Text(
                  selecao.diaDeDescanso
                      ? 'Fazer treino leve'
                      : selecao.treinoConcluidoHoje
                      ? 'Repetir treino'
                      : 'Iniciar treino',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _treinoCardHeader(
    BuildContext context, {
    required String titulo,
    required String subtitulo,
    bool mostrarSeta = true,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(30),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(
            Icons.fitness_center,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'TREINO DE HOJE',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: Colors.white60,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                titulo,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitulo,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
        ),
        if (mostrarSeta) const Icon(Icons.chevron_right, color: Colors.white60),
      ],
    );
  }

  Widget _buildStreakCard(BuildContext context) {
    final streak = _calcularStreak(historicoTreinos);
    final subtitulo = historicoTreinos.isEmpty
        ? 'Finalize um treino para iniciar sua sequencia.'
        : streak.treinouHoje
        ? 'Voce treinou hoje. Sequencia protegida.'
        : 'Treine hoje para manter ou iniciar uma nova sequencia.';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {},
        child: AppGradientCard(
          gradient: AppColors.gradientRun,
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: Colors.black.withAlpha(28),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(
                  Icons.local_fire_department_rounded,
                  color: Colors.black,
                  size: 32,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'SEQUÊNCIA',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${streak.atual} dia${streak.atual == 1 ? '' : 's'} em sequencia',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitulo,
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 13,
                        height: 1.3,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withAlpha(24),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Melhor',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${streak.melhor}',
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Card consolidado: Missões de Hoje (substitui Meta Diária + Desafios separados)
  Widget _buildMissoesCard(BuildContext context) {
    final treinosSemana = _treinosNaSemana(historicoTreinos);
    final xpSemana = _xpTreinosNaSemana(historicoTreinos);

    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.task_alt_rounded,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'MISSÕES DE HOJE',
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                    const SizedBox(height: 3),
                    const Text(
                      'Complete para ganhar XP e manter o ritmo.',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _missaoItem(
            icon: Icons.fitness_center_rounded,
            label: 'Concluir 1 treino hoje',
            detalhe: treinoConcluidoHoje ? 'Concluído ✓' : 'Pendente',
            progresso: treinoConcluidoHoje ? 1.0 : 0.0,
            concluido: treinoConcluidoHoje,
            color: AppColors.primary,
          ),
          const SizedBox(height: 14),
          _missaoItem(
            icon: Icons.directions_walk_rounded,
            label: '8.000 passos hoje',
            detalhe: '${widget.passos}/8000',
            progresso: widget.passos / 8000,
            concluido: widget.passos >= 8000,
            color: AppColors.accent1,
          ),
          const SizedBox(height: 14),
          _missaoItem(
            icon: Icons.bolt_rounded,
            label: '200 XP esta semana',
            detalhe: '$xpSemana/200 XP',
            progresso: xpSemana / 200,
            concluido: xpSemana >= 200,
            color: AppColors.accent2,
          ),
          const SizedBox(height: 14),
          _missaoItem(
            icon: Icons.calendar_today_rounded,
            label: '3 treinos nesta semana',
            detalhe: '$treinosSemana/3 treinos',
            progresso: treinosSemana / 3,
            concluido: treinosSemana >= 3,
            color: AppColors.accent3,
          ),
        ],
      ),
    );
  }

  Widget _missaoItem({
    required IconData icon,
    required String label,
    required String detalhe,
    required double progresso,
    required bool concluido,
    required Color color,
  }) {
    final valor = progresso.clamp(0.0, 1.0).toDouble();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: concluido ? color.withAlpha(35) : AppColors.surfaceVariant,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            concluido ? Icons.check_rounded : icon,
            color: concluido ? color : Colors.white70,
            size: 18,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      label,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    detalhe,
                    style: TextStyle(
                      color: concluido ? color : Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: LinearProgressIndicator(
                  value: valor,
                  minHeight: 6,
                  backgroundColor: AppColors.surfaceVariant,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Card consolidado: XP + Rank em um único card
  Widget _buildXpRankCard(BuildContext context) {
    final rankColor = _corRank();
    final rankIcon = _iconRank();
    final rankNome = rankAtual();
    final proximoRankNome = _proximoRank();
    final xpParaProximoNivel = 100;
    final xpAtualNoNivel = widget.xp % xpParaProximoNivel;
    final progresso = (xpAtualNoNivel / xpParaProximoNivel).clamp(0.0, 1.0);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {},
        child: AppGradientCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cabeçalho rank
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: rankColor.withAlpha(30),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(rankIcon, color: rankColor, size: 26),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'NÍVEL ${widget.nivel} · $rankNome',
                          style: Theme.of(context).textTheme.labelLarge
                              ?.copyWith(color: rankColor),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          rankNome,
                          style: Theme.of(
                            context,
                          ).textTheme.headlineSmall?.copyWith(
                            color: rankColor,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withAlpha(25),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(
                        color: AppColors.primary.withAlpha(70),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.bolt_rounded,
                          color: AppColors.primary,
                          size: 14,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${widget.xp} XP',
                          style: const TextStyle(
                            color: AppColors.primary,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Barra de XP
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'XP no nível',
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                  Text(
                    '$xpAtualNoNivel / $xpParaProximoNivel',
                    style: Theme.of(
                      context,
                    ).textTheme.labelLarge?.copyWith(color: AppColors.primary),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: Container(
                  height: 8,
                  decoration: const BoxDecoration(color: Color(0xFF2A2A2A)),
                  child: FractionallySizedBox(
                    widthFactor: progresso,
                    alignment: Alignment.centerLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [rankColor.withAlpha(200), AppColors.primary],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              if (rankNome != 'Diamante') ...[
                const SizedBox(height: 10),
                Text(
                  'Próximo rank: $proximoRankNome',
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecomendacaoCard(
    BuildContext context,
    _TreinoDoDiaSelecao selecao,
  ) {
    final recomendacaoAtual = recomendacao;

    if (carregandoTreinos && recomendacaoAtual == null) {
      return AppGradientCard(
        child: Row(
          children: const [
            SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            SizedBox(width: 14),
            Expanded(
              child: Text(
                'Ajustando recomendação do FitIA...',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      );
    }

    final recomendacaoFinal = _recomendacaoParaTreinoDoDia(
      selecao,
      recomendacaoAtual,
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {},
        child: AppGradientCard(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.tips_and_updates_rounded,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'FITIA RECOMENDA',
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      recomendacaoFinal.titulo,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      recomendacaoFinal.texto,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: AppColors.textSecondary,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _intensidadeChip(recomendacaoFinal.intensidade),
                        if (recomendacaoFinal.treinoRecomendado != null)
                          AppChip(
                            label: recomendacaoFinal.treinoRecomendado!.nome,
                            icon: Icons.fitness_center_rounded,
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    // Motivo amigável (sem "Motivo:" técnico)
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                            backgroundColor: AppColors.surface,
                            title: const Text(
                              'Por que essa recomendação?',
                              style: TextStyle(color: Colors.white),
                            ),
                            content: Text(
                              recomendacaoFinal.motivo,
                              style: const TextStyle(
                                color: Colors.white70,
                                height: 1.5,
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text('Entendi'),
                              ),
                            ],
                          ),
                        );
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          Icon(
                            Icons.help_outline_rounded,
                            size: 14,
                            color: Colors.white38,
                          ),
                          SizedBox(width: 5),
                          Text(
                            'Por que essa recomendação?',
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IaEvolutivaRecomendacao _recomendacaoParaTreinoDoDia(
    _TreinoDoDiaSelecao selecao,
    IaEvolutivaRecomendacao? recomendacaoBase,
  ) {
    final treino = selecao.treino;

    if (selecao.treinoConcluidoHoje || selecao.todosTreinosConcluidosHoje) {
      return IaEvolutivaRecomendacao(
        titulo: 'Treino do dia concluído',
        texto:
            'Você já concluiu o treino de hoje. Faça recuperação, alongamento ou caminhada leve.',
        motivo: selecao.motivo,
        intensidade: 'leve',
        treinoRecomendado: treino,
      );
    }

    if (selecao.diaDeDescanso) {
      return IaEvolutivaRecomendacao(
        titulo: 'Dia de recuperação',
        texto: treino == null
            ? 'Hoje é um bom dia para recuperar. Faça alongamento, mobilidade ou caminhada leve.'
            : 'Hoje é dia de recuperação. Se quiser se movimentar, ${treino.nome} é uma boa opção leve.',
        motivo: selecao.motivo,
        intensidade: 'leve',
        treinoRecomendado: treino,
      );
    }

    if (treino != null) {
      return IaEvolutivaRecomendacao(
        titulo: 'Hoje é dia de ${treino.nome}',
        texto:
            'Hoje é dia de ${treino.nome}. Mantenha consistência e conclua todos os exercícios.',
        motivo: selecao.motivo,
        intensidade: recomendacaoBase?.intensidade ?? 'moderado',
        treinoRecomendado: treino,
      );
    }

    return recomendacaoBase ??
        const IaEvolutivaRecomendacao(
          titulo: 'Primeiro passo inteligente',
          texto: 'Crie uma ficha ou gere uma com IA para começar.',
          motivo: 'Ainda não existem treinos disponíveis.',
          intensidade: 'leve',
        );
  }

  Widget _intensidadeChip(String intensidade) {
    final cor = _corIntensidade(intensidade);

    return AppChip(
      label: intensidade[0].toUpperCase() + intensidade.substring(1),
      color: cor,
      icon: Icons.bolt_rounded,
    );
  }

  Color _corIntensidade(String intensidade) {
    switch (intensidade.toLowerCase()) {
      case 'leve':
        return AppColors.accent1;
      case 'intenso':
        return AppColors.accent2;
      case 'moderado':
      default:
        return AppColors.primary;
    }
  }
}
