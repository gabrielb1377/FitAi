import 'package:flutter/material.dart';

import '../../models/historico_treino_model.dart';
import '../../models/treino_model.dart';
import '../../services/ia_evolutiva_service.dart';
import '../../services/storage_service.dart';
import '../../services/streak_service.dart';
import '../../services/treino_do_dia_service.dart';
import '../../services/treino_service.dart';
import '../../theme/app_theme.dart';
import '../ai_workout_page.dart';
import '../treinos/criar_treino_page.dart';
import '../treinos/treino_profissional_page.dart';
import 'widgets/fitia_recomendacao_card.dart';
import 'widgets/header_home.dart';
import 'widgets/home_stats_row.dart';
import 'widgets/missoes_hoje_card.dart';
import 'widgets/streak_card.dart';
import 'widgets/treino_do_dia_card.dart';
import 'widgets/xp_rank_card.dart';

class HomePage extends StatefulWidget {
  final String nome;
  final double distancia;
  final int passos;
  final int xp;
  final int nivel;
  final Future<void> Function()? onXpAtualizado;

  const HomePage({
    super.key,
    required this.nome,
    required this.distancia,
    required this.passos,
    required this.xp,
    required this.nivel,
    this.onXpAtualizado,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final treinoService = TreinoService.instance;
  final treinoDoDiaService = const TreinoDoDiaService();
  final streakService = const StreakService();

  bool carregandoTreinos = true;
  bool atualizandoDadosHoje = false;
  bool treinoConcluidoHoje = false;
  List<HistoricoTreinoModel> historicoTreinos = [];
  IaEvolutivaRecomendacao? recomendacao;

  @override
  void initState() {
    super.initState();
    treinoService.addListener(_onTreinosAtualizados);
    _carregarDadosHoje();
  }

  @override
  void dispose() {
    treinoService.removeListener(_onTreinosAtualizados);
    super.dispose();
  }

  void _onTreinosAtualizados() {
    if (!mounted) return;
    _carregarDadosHoje();
  }

  Future<void> _carregarDadosHoje() async {
    if (atualizandoDadosHoje) return;

    atualizandoDadosHoje = true;

    try {
      final historico = await StorageService.carregarHistoricoTreinos();
      final recomendacaoAtual = await IaEvolutivaService.instance
          .gerarRecomendacao(
            treinosDisponiveis: treinoService.treinos,
            historico: historico,
            xpAtual: widget.xp,
            nivelAtual: widget.nivel,
          );
      final concluiuHoje = treinoDoDiaService.existeTreinoConcluidoHoje(
        historico,
      );

      if (!mounted) return;

      setState(() {
        treinoConcluidoHoje = concluiuHoje;
        historicoTreinos = historico;
        recomendacao = recomendacaoAtual;
        carregandoTreinos = false;
      });
    } finally {
      atualizandoDadosHoje = false;
    }
  }

  Future<void> _abrirTreino(TreinoModel treino) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TreinoProfissionalPage(
          treino: treino,
          onXpAtualizado: widget.onXpAtualizado,
        ),
      ),
    );

    final atualizarXp = widget.onXpAtualizado;
    if (atualizarXp != null) {
      await atualizarXp();
    }

    await _carregarDadosHoje();
  }

  Future<void> _abrirCriarTreino() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CriarTreinoPage()),
    );

    await _carregarDadosHoje();
  }

  Future<void> _abrirGeradorIa() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AIWorkoutPage()),
    );

    await _carregarDadosHoje();
  }

  @override
  Widget build(BuildContext context) {
    final selecaoTreino = treinoDoDiaService.selecionarTreinoDoDiaDetalhado(
      treinoService.treinos,
      historicoTreinos,
    );
    final streak = streakService.calcularStreak(historicoTreinos);
    final treinosSemana = streakService.treinosNaSemana(historicoTreinos);
    final xpSemana = streakService.xpTreinosNaSemana(historicoTreinos);
    const cardGap = 16.0;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: HeaderHome(nome: widget.nome, nivel: widget.nivel),
          ),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(
              _horizontalPadding(context),
              0,
              _horizontalPadding(context),
              100,
            ),
            sliver: SliverList(
              delegate: SliverChildListDelegate.fixed([
                HomeStatsRow(
                  distancia: widget.distancia,
                  passos: widget.passos,
                ),
                const SizedBox(height: cardGap),
                TreinoDoDiaCard(
                  selecao: selecaoTreino,
                  carregandoTreinos: carregandoTreinos,
                  onAbrirTreino: _abrirTreino,
                  onCriarTreino: _abrirCriarTreino,
                  onGerarIa: _abrirGeradorIa,
                ),
                const SizedBox(height: cardGap),
                FitiaRecomendacaoCard(
                  selecao: selecaoTreino,
                  recomendacao: recomendacao,
                  carregandoTreinos: carregandoTreinos,
                ),
                const SizedBox(height: cardGap),
                MissoesHojeCard(
                  treinoConcluidoHoje: treinoConcluidoHoje,
                  passos: widget.passos,
                  treinosSemana: treinosSemana,
                  xpSemana: xpSemana,
                ),
                const SizedBox(height: cardGap),
                StreakCard(
                  streak: streak,
                  historicoVazio: historicoTreinos.isEmpty,
                ),
                const SizedBox(height: cardGap),
                XpRankCard(xp: widget.xp, nivel: widget.nivel),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}
