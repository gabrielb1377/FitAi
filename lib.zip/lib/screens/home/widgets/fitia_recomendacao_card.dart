import 'package:flutter/material.dart';

import '../../../services/ia_evolutiva_service.dart';
import '../../../services/treino_do_dia_service.dart';
import '../../../theme/app_theme.dart';

class FitiaRecomendacaoCard extends StatelessWidget {
  final TreinoDoDiaSelecao selecao;
  final IaEvolutivaRecomendacao? recomendacao;
  final bool carregandoTreinos;

  const FitiaRecomendacaoCard({
    super.key,
    required this.selecao,
    required this.recomendacao,
    required this.carregandoTreinos,
  });

  @override
  Widget build(BuildContext context) {
    if (carregandoTreinos && recomendacao == null) {
      return const AppLoadingCard(
        message: 'Ajustando recomendação do FitIA...',
      );
    }

    final recomendacaoFinal = _recomendacaoParaTreinoDoDia(
      selecao,
      recomendacao,
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () {},
        child: AppGradientCard(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: AppColors.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.tips_and_updates_rounded,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'FITIA RECOMENDA',
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      recomendacaoFinal.titulo,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      recomendacaoFinal.texto,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: AppColors.textSecondary,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _intensidadeChip(recomendacaoFinal.intensidade),
                        if (recomendacaoFinal.treinoRecomendado != null)
                          AppChip(
                            label: recomendacaoFinal.treinoRecomendado!.nome,
                            icon: Icons.fitness_center_rounded,
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                            backgroundColor: AppColors.surface,
                            title: const Text(
                              'Por que essa recomendação?',
                              style: TextStyle(color: Colors.white),
                            ),
                            content: Text(
                              recomendacaoFinal.motivo,
                              style: const TextStyle(
                                color: Colors.white70,
                                height: 1.5,
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text('Entendi'),
                              ),
                            ],
                          ),
                        );
                      },
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.help_outline_rounded,
                            size: 14,
                            color: Colors.white38,
                          ),
                          SizedBox(width: 5),
                          Text(
                            'Por que essa recomendação?',
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IaEvolutivaRecomendacao _recomendacaoParaTreinoDoDia(
    TreinoDoDiaSelecao selecao,
    IaEvolutivaRecomendacao? recomendacaoBase,
  ) {
    final treino = selecao.treino;

    if (selecao.treinoConcluidoHoje || selecao.todosTreinosConcluidosHoje) {
      return IaEvolutivaRecomendacao(
        titulo: 'Treino do dia concluído',
        texto:
            'Você já concluiu o treino de hoje. Faça recuperação, alongamento ou caminhada leve.',
        motivo: selecao.motivo,
        intensidade: 'leve',
        treinoRecomendado: treino,
      );
    }

    if (selecao.diaDeDescanso) {
      return IaEvolutivaRecomendacao(
        titulo: 'Dia de recuperação',
        texto: treino == null
            ? 'Hoje é um bom dia para recuperar. Faça alongamento, mobilidade ou caminhada leve.'
            : 'Hoje é dia de recuperação. Se quiser se movimentar, ${treino.nome} é uma boa opção leve.',
        motivo: selecao.motivo,
        intensidade: 'leve',
        treinoRecomendado: treino,
      );
    }

    if (treino != null) {
      return IaEvolutivaRecomendacao(
        titulo: 'Hoje é dia de ${treino.nome}',
        texto:
            'Hoje é dia de ${treino.nome}. Mantenha consistência e conclua todos os exercícios.',
        motivo: selecao.motivo,
        intensidade: recomendacaoBase?.intensidade ?? 'moderado',
        treinoRecomendado: treino,
      );
    }

    return recomendacaoBase ??
        const IaEvolutivaRecomendacao(
          titulo: 'Primeiro passo inteligente',
          texto: 'Crie uma ficha ou gere uma com IA para começar.',
          motivo: 'Ainda não existem treinos disponíveis.',
          intensidade: 'leve',
        );
  }

  Widget _intensidadeChip(String intensidade) {
    final cor = _corIntensidade(intensidade);
    final label = intensidade.isEmpty
        ? 'Moderado'
        : intensidade[0].toUpperCase() + intensidade.substring(1);

    return AppChip(label: label, color: cor, icon: Icons.bolt_rounded);
  }

  Color _corIntensidade(String intensidade) {
    switch (intensidade.toLowerCase()) {
      case 'leve':
        return AppColors.accent1;
      case 'intenso':
        return AppColors.accent2;
      case 'moderado':
      default:
        return AppColors.primary;
    }
  }
}
