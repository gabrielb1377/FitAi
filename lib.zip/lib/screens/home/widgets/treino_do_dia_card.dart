import 'package:flutter/material.dart';

import '../../../models/treino_model.dart';
import '../../../services/treino_do_dia_service.dart';
import '../../../theme/app_theme.dart';

class TreinoDoDiaCard extends StatelessWidget {
  final TreinoDoDiaSelecao selecao;
  final bool carregandoTreinos;
  final Future<void> Function(TreinoModel treino) onAbrirTreino;
  final Future<void> Function() onCriarTreino;
  final Future<void> Function() onGerarIa;

  const TreinoDoDiaCard({
    super.key,
    required this.selecao,
    required this.carregandoTreinos,
    required this.onAbrirTreino,
    required this.onCriarTreino,
    required this.onGerarIa,
  });

  @override
  Widget build(BuildContext context) {
    final treino = selecao.treino;

    if (carregandoTreinos && treino == null) {
      return const AppLoadingCard(
        message: 'Buscando seu treino de hoje...',
        gradient: AppColors.gradientWorkout,
      );
    }

    if (treino == null) {
      return AppGradientCard(
        gradient: AppColors.gradientWorkout,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TreinoCardHeader(
              titulo: selecao.titulo,
              subtitulo: selecao.descricao,
              mostrarSeta: !selecao.diaDeDescanso,
            ),
            if (!selecao.diaDeDescanso) ...[
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () {
                  onCriarTreino();
                },
                icon: const Icon(Icons.add_rounded),
                label: const Text('Criar treino'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () {
                  onGerarIa();
                },
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text('Gerar com IA'),
              ),
            ],
          ],
        ),
      );
    }

    final titulo = selecao.diaDeDescanso
        ? 'Dia de recuperação'
        : selecao.treinoConcluidoHoje
        ? 'Treino do dia concluído'
        : treino.nome;
    final subtitulo = selecao.diaDeDescanso
        ? '${selecao.descricao} Sugestão leve: ${treino.nome}.'
        : selecao.treinoConcluidoHoje
        ? '${selecao.descricao} ${treino.exercicios.length} exercícios • ${treino.tempoEstimado} min'
        : '${treino.exercicios.length} exercícios • ${treino.tempoEstimado} min';

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () {
          onAbrirTreino(treino);
        },
        borderRadius: BorderRadius.circular(20),
        child: AppGradientCard(
          gradient: AppColors.gradientWorkout,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _TreinoCardHeader(titulo: titulo, subtitulo: subtitulo),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (selecao.diaDeDescanso)
                    const AppChip(label: 'Recuperação', dark: true),
                  if (selecao.treinoConcluidoHoje)
                    const AppChip(label: 'Concluído hoje', dark: true),
                  AppChip(label: treino.objetivo, dark: true),
                  AppChip(label: treino.nivel, dark: true),
                  if (treino.criadoPorIA)
                    const AppChip(
                      label: 'IA',
                      icon: Icons.auto_awesome_rounded,
                      dark: true,
                    ),
                ],
              ),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () {
                  onAbrirTreino(treino);
                },
                icon: Icon(
                  selecao.treinoConcluidoHoje
                      ? Icons.replay_rounded
                      : Icons.play_arrow_rounded,
                ),
                label: Text(
                  selecao.diaDeDescanso
                      ? 'Fazer treino leve'
                      : selecao.treinoConcluidoHoje
                      ? 'Repetir treino'
                      : 'Iniciar treino',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TreinoCardHeader extends StatelessWidget {
  final String titulo;
  final String subtitulo;
  final bool mostrarSeta;

  const _TreinoCardHeader({
    required this.titulo,
    required this.subtitulo,
    this.mostrarSeta = true,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(30),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(
            Icons.fitness_center,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'TREINO DE HOJE',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: Colors.white60,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                titulo,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitulo,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ],
          ),
        ),
        if (mostrarSeta) const Icon(Icons.chevron_right, color: Colors.white60),
      ],
    );
  }
}
