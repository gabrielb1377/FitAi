import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/achievement_model.dart';
import '../../models/exercicio_model.dart';
import '../../models/historico_serie_treino_model.dart';
import '../../models/historico_treino_model.dart';
import '../../models/progresso_exercicio_model.dart';
import '../../models/treino_model.dart';
import '../../services/achievement_service.dart';
import '../../services/progressao_service.dart';
import '../../services/recorde_service.dart';
import '../../services/storage_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/exercicio_gif_viewer.dart';

class TreinoProfissionalPage extends StatefulWidget {
  final TreinoModel treino;
  final Future<void> Function()? onXpAtualizado;

  const TreinoProfissionalPage({
    super.key,
    required this.treino,
    this.onXpAtualizado,
  });

  @override
  State<TreinoProfissionalPage> createState() => _TreinoProfissionalPageState();
}

class _TreinoProfissionalPageState extends State<TreinoProfissionalPage> {
  static const int _totalSeries = 3;
  static const int _descansoPadrao = 60;

  final pesoController = TextEditingController(text: "0");
  final repeticoesController = TextEditingController(text: "10");
  final descansoController = TextEditingController(text: "$_descansoPadrao");

  final Map<int, Set<int>> seriesConcluidas = {};
  final Map<String, _SerieExecutada> seriesExecutadas = {};
  final Map<String, ResultadoRecorde> recordesPorSerie = {};
  final String sessaoTreinoId =
      "sessao_${DateTime.now().microsecondsSinceEpoch}";
  final ProgressaoService progressaoService = const ProgressaoService();
  final RecordeService recordeService = const RecordeService();

  Timer? treinoTimer;
  Timer? descansoTimer;
  ProgressaoSugestao? progressaoAtual;
  int indiceAtual = 0;
  int segundos = 0;
  int descansoTotal = 0;
  int descansoRestante = 0;
  bool avancarAoFimDoDescanso = false;
  bool finalizando = false;

  List<ExercicioModel> get exercicios => widget.treino.exercicios;

  ExercicioModel? get exercicioAtual {
    if (exercicios.isEmpty) return null;
    return exercicios[indiceAtual.clamp(0, exercicios.length - 1)];
  }

  Set<int> get _seriesAtual {
    return seriesConcluidas.putIfAbsent(indiceAtual, () => <int>{});
  }

  int get exerciciosConcluidos {
    var total = 0;
    for (var index = 0; index < exercicios.length; index++) {
      if ((seriesConcluidas[index] ?? const <int>{}).length >= _totalSeries) {
        total++;
      }
    }
    return total;
  }

  int get totalSeriesConcluidas {
    return seriesConcluidas.values.fold<int>(
      0,
      (total, series) => total + series.length,
    );
  }

  double get volumeTotalEstimado {
    var total = 0.0;

    for (final entrada in seriesConcluidas.entries) {
      for (final serieIndex in entrada.value) {
        final serie = seriesExecutadas[_serieId(entrada.key, serieIndex)];
        if (serie != null) total += serie.volume;
      }
    }

    return total;
  }

  int get recordesBatidos {
    return recordesPorSerie.values.fold<int>(
      0,
      (total, resultado) => total + resultado.tipos.length,
    );
  }

  double get progresso {
    if (exercicios.isEmpty) return 0;
    return (indiceAtual + 1) / exercicios.length;
  }

  String get tempoFormatado {
    final minutos = segundos ~/ 60;
    final segundo = segundos % 60;
    return "${minutos.toString().padLeft(2, "0")}:${segundo.toString().padLeft(2, "0")}";
  }

  int get xpGanho {
    final treinoCompleto =
        exercicios.isNotEmpty && exerciciosConcluidos == exercicios.length;
    return 20 +
        (exerciciosConcluidos * 10) +
        (treinoCompleto ? 5 : 0) +
        (recordesBatidos * 20);
  }

  int get caloriasEstimadas {
    final concluidos = <ExercicioModel>[];
    for (var index = 0; index < exercicios.length; index++) {
      if ((seriesConcluidas[index] ?? const <int>{}).length >= _totalSeries) {
        concluidos.add(exercicios[index]);
      }
    }

    final base = concluidos.isEmpty ? exercicios : concluidos;
    final calorias = base
        .map((exercicio) => exercicio.caloriasHora)
        .where((valor) => valor > 0)
        .toList();

    if (calorias.isEmpty) return 0;

    final media = calorias.reduce((a, b) => a + b) / calorias.length;
    final minutosPorExercicio = exercicios.isEmpty
        ? 0.0
        : widget.treino.tempoEstimado / exercicios.length;
    final horas = segundos > 0
        ? segundos / 3600
        : (minutosPorExercicio * exerciciosConcluidos) / 60;

    return (media * horas).round();
  }

  @override
  void initState() {
    super.initState();
    _iniciarCronometro();
    _carregarUltimoProgresso();
  }

  void _iniciarCronometro() {
    treinoTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        segundos++;
      });
    });
  }

  Future<void> _carregarUltimoProgresso() async {
    final indiceCarregado = indiceAtual;
    final exercicio = exercicioAtual;
    if (exercicio == null) return;

    setState(() {
      progressaoAtual = null;
    });

    final sugestao = await progressaoService.calcularSugestao(
      exercicio: exercicio,
      metaRepeticoes: 10,
    );
    final progresso = await StorageService.carregarUltimoProgresso(
      exercicio.nome,
    );

    if (!mounted || indiceCarregado != indiceAtual) return;

    setState(() {
      progressaoAtual = sugestao;
      pesoController.text = sugestao.cargaSugerida > 0
          ? _formatarNumero(sugestao.cargaSugerida)
          : progresso == null || progresso.peso <= 0
          ? "0"
          : _formatarNumero(progresso.peso);
      repeticoesController.text = sugestao.repeticoesMax.toString();
      descansoController.text = (progresso?.tempoDescanso ?? _descansoPadrao)
          .toString();
    });
  }

  @override
  void dispose() {
    treinoTimer?.cancel();
    descansoTimer?.cancel();
    pesoController.dispose();
    repeticoesController.dispose();
    descansoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final exercicio = exercicioAtual;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(widget.treino.nome)),
      body: exercicio == null
          ? const _TreinoProfissionalVazio()
          : ListView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.fromLTRB(
                _horizontalPadding(context),
                16,
                _horizontalPadding(context),
                28,
              ),
              children: [
                _barraSuperiorCard(),
                const SizedBox(height: 16),
                _estatisticasTempoRealCard(),
                const SizedBox(height: 16),
                _gifCard(exercicio),
                const SizedBox(height: 16),
                _exercicioHeader(exercicio),
                const SizedBox(height: 16),
                _progressaoCard(),
                const SizedBox(height: 16),
                _seriesCard(),
                const SizedBox(height: 16),
                _cargaCard(),
                const SizedBox(height: 16),
                _descansoCard(),
                const SizedBox(height: 18),
                ElevatedButton.icon(
                  onPressed: finalizando ? null : _concluirProximaSerie,
                  icon: const Icon(Icons.check_circle_rounded),
                  label: const Text("Concluir serie"),
                ),
                const SizedBox(height: 12),
                _navegacao(),
              ],
            ),
    );
  }

  Widget _barraSuperiorCard() {
    final total = exercicios.length;

    return AppGradientCard(
      gradient: AppColors.gradientPrimary,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.treino.nome,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Text(
                  "EXERCICIO ${indiceAtual + 1}/$total",
                  style: const TextStyle(
                    color: Colors.black54,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
              Text(
                tempoFormatado,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: progresso.clamp(0.0, 1.0).toDouble(),
              minHeight: 9,
              color: Colors.black,
              backgroundColor: Colors.black26,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            "$exerciciosConcluidos/$total exercicios finalizados",
            style: const TextStyle(
              color: Colors.black87,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _estatisticasTempoRealCard() {
    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Dashboard do treino",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _statTile(
                icon: Icons.timer_rounded,
                label: "Tempo",
                value: tempoFormatado,
                color: AppColors.primary,
              ),
              _statTile(
                icon: Icons.format_list_numbered_rounded,
                label: "Series",
                value: "$totalSeriesConcluidas",
                color: AppColors.accent1,
              ),
              _statTile(
                icon: Icons.check_circle_rounded,
                label: "Exercicios",
                value: "$exerciciosConcluidos/${exercicios.length}",
                color: AppColors.primaryLight,
              ),
              _statTile(
                icon: Icons.monitor_weight_rounded,
                label: "Volume",
                value: "${_formatarNumero(volumeTotalEstimado)} kg",
                color: AppColors.accent2,
              ),
              _statTile(
                icon: Icons.bolt_rounded,
                label: "XP ganho",
                value: "+$xpGanho",
                color: AppColors.accent3,
              ),
              _statTile(
                icon: Icons.emoji_events_rounded,
                label: "Recordes",
                value: "$recordesBatidos",
                color: AppColors.rankOuro,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statTile({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return SizedBox(
      width: 150,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF2A2A2A)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 10),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white60,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _gifCard(ExercicioModel exercicio) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => mostrarGifExercicioTelaCheia(
        context,
        imagem: exercicio.imagem,
        titulo: exercicio.nome,
        subtitulo: exercicio.categoria,
      ),
      child: AppGradientCard(
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 220, minHeight: 180),
            child: SizedBox(
              height: 200,
              width: double.infinity,
              child: _gif(exercicio),
            ),
          ),
        ),
      ),
    );
  }

  Widget _gif(ExercicioModel exercicio) {
    final imagem = exercicio.imagem.trim();
    if (imagem.isEmpty) return _gifFallback(exercicio);

    final isNetwork =
        imagem.startsWith("http://") || imagem.startsWith("https://");

    if (isNetwork) {
      return Image.network(
        imagem,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.low,
        errorBuilder: (_, _, _) => _gifFallback(exercicio),
      );
    }

    return Image.asset(
      imagem,
      fit: BoxFit.contain,
      cacheWidth: 900,
      filterQuality: FilterQuality.low,
      semanticLabel: exercicio.nome,
      errorBuilder: (_, _, _) => _gifFallback(exercicio),
    );
  }

  Widget _gifFallback(ExercicioModel exercicio) {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.gradientWorkout),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.fitness_center_rounded,
              color: Colors.white,
              size: 48,
            ),
            const SizedBox(height: 10),
            Text(
              exercicio.categoria,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _exercicioHeader(ExercicioModel exercicio) {
    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            exercicio.nome,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _textoMusculos(exercicio),
            style: const TextStyle(color: Colors.white70, height: 1.35),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _chip(exercicio.categoria, Icons.category_rounded),
              _chip(exercicio.dificuldade, Icons.trending_up_rounded),
              _chip("Meta ${repeticoesController.text} reps", Icons.repeat),
            ],
          ),
        ],
      ),
    );
  }

  Widget _progressaoCard() {
    final sugestao = progressaoAtual;

    return AppGradientCard(
      child: sugestao == null
          ? const Row(
              children: [
                SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.4),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "Calculando progressao inteligente...",
                    style: TextStyle(
                      color: Colors.white70,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _progressaoColor(sugestao.tipo).withAlpha(32),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(
                        _progressaoIcon(sugestao.tipo),
                        color: _progressaoColor(sugestao.tipo),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Sugestao para hoje",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            _progressaoLabel(sugestao.tipo),
                            style: TextStyle(
                              color: _progressaoColor(sugestao.tipo),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _progressaoLinha(
                  label: "Ultima execucao",
                  value: _ultimaExecucaoTexto(sugestao),
                  subvalue: _ultimaExecucaoData(sugestao),
                ),
                const SizedBox(height: 12),
                _progressaoLinha(
                  label: "Para hoje",
                  value: _sugestaoTexto(sugestao),
                  subvalue: sugestao.motivo,
                ),
              ],
            ),
    );
  }

  Widget _progressaoLinha({
    required String label,
    required String value,
    required String subvalue,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          if (subvalue.trim().isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              subvalue,
              style: const TextStyle(color: Colors.white60, height: 1.35),
            ),
          ],
        ],
      ),
    );
  }

  Widget _seriesCard() {
    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Series",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 12),
          for (var index = 0; index < _totalSeries; index++) _serieLinha(index),
        ],
      ),
    );
  }

  Widget _serieLinha(int index) {
    final concluida = _seriesAtual.contains(index);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => _alternarSerie(index, !concluida),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: concluida
                ? AppColors.primary.withAlpha(28)
                : AppColors.surfaceVariant,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: concluida ? AppColors.primary : const Color(0xFF2A2A2A),
            ),
          ),
          child: Row(
            children: [
              Checkbox(
                value: concluida,
                activeColor: AppColors.primary,
                checkColor: Colors.black,
                onChanged: (valor) => _alternarSerie(index, valor ?? false),
              ),
              Expanded(
                child: Text(
                  "Serie ${index + 1}",
                  style: TextStyle(
                    color: concluida ? Colors.white : Colors.white70,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              Text(
                "${repeticoesController.text.trim().isEmpty ? "10" : repeticoesController.text.trim()} reps",
                style: const TextStyle(
                  color: Colors.white54,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cargaCard() {
    return AppGradientCard(
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: pesoController,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: "Peso",
                suffixText: "kg",
                prefixIcon: Icon(Icons.fitness_center_rounded),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: TextField(
              controller: repeticoesController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Repeticoes",
                suffixText: "reps",
                prefixIcon: Icon(Icons.repeat_rounded),
              ),
              onChanged: (_) => setState(() {}),
            ),
          ),
        ],
      ),
    );
  }

  Widget _descansoCard() {
    final descansoAtivo = descansoRestante > 0;
    final progressoDescanso = descansoTotal <= 0
        ? 0.0
        : 1 - (descansoRestante / descansoTotal);

    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.timer_rounded, color: AppColors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  descansoAtivo ? "Descanso em andamento" : "Descanso",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (descansoAtivo) ...[
            Center(
              child: Text(
                "$descansoRestante",
                style: const TextStyle(
                  color: AppColors.primary,
                  fontSize: 64,
                  fontWeight: FontWeight.w900,
                  height: 0.95,
                ),
              ),
            ),
            const SizedBox(height: 4),
            const Center(
              child: Text(
                "segundos",
                style: TextStyle(
                  color: Colors.white60,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Center(
              child: Text(
                _formatarTempo(descansoRestante),
                style: const TextStyle(
                  color: Colors.white54,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: progressoDescanso.clamp(0.0, 1.0).toDouble(),
                minHeight: 9,
                color: AppColors.primary,
                backgroundColor: const Color(0xFF2A2A2A),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _pularDescanso,
                    child: const Text("Pular descanso"),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 74,
                  child: OutlinedButton(
                    onPressed: () => _ajustarDescanso(15),
                    child: const Text("+15s"),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 74,
                  child: OutlinedButton(
                    onPressed: () => _ajustarDescanso(-15),
                    child: const Text("-15s"),
                  ),
                ),
              ],
            ),
          ] else
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: descansoController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: "Descanso",
                      suffixText: "s",
                      prefixIcon: Icon(Icons.hourglass_bottom_rounded),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 128,
                  child: OutlinedButton(
                    onPressed: _iniciarDescanso,
                    child: const Text("Iniciar"),
                  ),
                ),
              ],
            ),
          if (!descansoAtivo) ...[
            const SizedBox(height: 10),
            const Text(
              "Padrao de 60s quando nenhum descanso estiver definido.",
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }

  Widget _navegacao() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: indiceAtual == 0 ? null : _anterior,
            icon: const Icon(Icons.chevron_left_rounded),
            label: const Text("Anterior"),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: finalizando ? null : _proximo,
            icon: const Icon(Icons.chevron_right_rounded),
            label: const Text("Proximo"),
          ),
        ),
      ],
    );
  }

  Widget _chip(String texto, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.primary, size: 15),
          const SizedBox(width: 6),
          Text(
            texto,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _alternarSerie(int index, bool concluida) async {
    final exercicio = exercicioAtual;
    if (exercicio == null || finalizando) return;

    final jaConcluida = _seriesAtual.contains(index);
    final serieId = _serieId(indiceAtual, index);

    setState(() {
      if (concluida) {
        _seriesAtual.add(index);
      } else {
        _seriesAtual.remove(index);
        seriesExecutadas.remove(serieId);
        recordesPorSerie.remove(serieId);
      }
    });

    if (!concluida && jaConcluida) {
      await _removerDadosSerie(index);
      return;
    }

    if (concluida && !jaConcluida) {
      await _salvarProgressoSerie(exercicio, index);
      if (!mounted) return;
      _iniciarDescanso(avancarAoFinal: _seriesAtual.length >= _totalSeries);
      return;
    }
  }

  Future<void> _concluirProximaSerie() async {
    for (var index = 0; index < _totalSeries; index++) {
      if (!_seriesAtual.contains(index)) {
        await _alternarSerie(index, true);
        return;
      }
    }

    await _avancarOuFinalizar();
  }

  Future<void> _salvarProgressoSerie(
    ExercicioModel exercicio,
    int serieIndex,
  ) async {
    final agora = DateTime.now();
    final serieId = _serieId(indiceAtual, serieIndex);
    final progressoId = "progresso_$serieId";
    final historicoId = "serie_$serieId";
    final peso = _parsePeso();
    final repeticoes = _parseRepeticoes();
    final recorde = await recordeService.detectarRecordes(
      exercicio: exercicio,
      peso: peso,
      repeticoes: repeticoes,
    );

    seriesExecutadas[serieId] = _SerieExecutada(
      peso: peso,
      repeticoes: repeticoes,
    );
    if (recorde.bateuRecorde) {
      recordesPorSerie[serieId] = recorde;
    } else {
      recordesPorSerie.remove(serieId);
    }

    await StorageService.removerProgresso(progressoId);
    await StorageService.salvarProgresso(
      ProgressoExercicioModel(
        id: progressoId,
        nomeExercicio: exercicio.nome,
        peso: peso,
        series: serieIndex + 1,
        repeticoes: repeticoes,
        tempoDescanso: _parseDescanso(),
        observacao: "Plano: ${widget.treino.nome}",
        data: agora,
      ),
    );

    await StorageService.salvarHistoricoSerieTreino(
      HistoricoSerieTreinoModel(
        id: historicoId,
        treinoId: widget.treino.id,
        sessaoTreinoId: sessaoTreinoId,
        nomeTreino: widget.treino.nome,
        exercicioId: exercicio.id,
        nomeExercicio: exercicio.nome,
        serieNumero: serieIndex + 1,
        peso: peso,
        repeticoes: repeticoes,
        dataHora: agora,
      ),
    );

    if (recorde.bateuRecorde && mounted) {
      _mostrarRecorde(recorde);
    }
  }

  Future<void> _removerDadosSerie(int serieIndex) async {
    final serieId = _serieId(indiceAtual, serieIndex);

    await StorageService.removerProgresso("progresso_$serieId");
    await StorageService.removerHistoricoSerieTreino("serie_$serieId");
  }

  void _mostrarRecorde(ResultadoRecorde recorde) {
    final tipos = recorde.tipos.map(_recordeLabel).join(", ");

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.rankOuro,
        content: Text(
          tipos.isEmpty
              ? "🏆 Novo recorde pessoal!"
              : "🏆 Novo recorde pessoal! $tipos",
          style: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }

  void _iniciarDescanso({bool avancarAoFinal = false}) {
    descansoTimer?.cancel();
    final total = _parseDescanso();

    setState(() {
      descansoTotal = total;
      descansoRestante = total;
      avancarAoFimDoDescanso = avancarAoFinal;
    });

    descansoTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }

      if (descansoRestante <= 1) {
        timer.cancel();
        _encerrarDescanso(mostrarMensagem: true, avancarSeNecessario: true);
        return;
      }

      setState(() {
        descansoRestante--;
      });
    });
  }

  void _pularDescanso() {
    _encerrarDescanso(mostrarMensagem: true, avancarSeNecessario: true);
  }

  void _cancelarDescanso() {
    _encerrarDescanso(mostrarMensagem: false, avancarSeNecessario: false);
  }

  void _encerrarDescanso({
    required bool mostrarMensagem,
    required bool avancarSeNecessario,
  }) {
    descansoTimer?.cancel();
    if (!mounted) return;

    final deveAvancar = avancarAoFimDoDescanso;

    setState(() {
      descansoTotal = 0;
      descansoRestante = 0;
      avancarAoFimDoDescanso = false;
    });

    if (mostrarMensagem) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Descanso finalizado")));
    }

    if (deveAvancar && avancarSeNecessario) {
      unawaited(_avancarOuFinalizar());
    }
  }

  void _ajustarDescanso(int segundos) {
    if (descansoRestante <= 0) return;

    final novoRestante = (descansoRestante + segundos).clamp(0, 600).toInt();

    if (novoRestante <= 0) {
      _encerrarDescanso(mostrarMensagem: true, avancarSeNecessario: true);
      return;
    }

    setState(() {
      descansoRestante = novoRestante;
      descansoTotal = (descansoTotal + segundos)
          .clamp(novoRestante, 600)
          .toInt();
      descansoController.text = novoRestante.toString();
    });
  }

  Future<void> _avancarOuFinalizar() async {
    if (indiceAtual >= exercicios.length - 1) {
      await _finalizarTreino();
      return;
    }

    _cancelarDescanso();

    setState(() {
      indiceAtual++;
    });

    await _carregarUltimoProgresso();
  }

  void _anterior() {
    if (indiceAtual == 0) return;

    _cancelarDescanso();
    setState(() {
      indiceAtual--;
    });
    _carregarUltimoProgresso();
  }

  Future<void> _proximo() async {
    if (indiceAtual >= exercicios.length - 1) {
      if (_seriesAtual.length >= _totalSeries) {
        await _finalizarTreino();
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Conclua as series para finalizar.")),
      );
      return;
    }

    _cancelarDescanso();
    setState(() {
      indiceAtual++;
    });
    await _carregarUltimoProgresso();
  }

  Future<void> _finalizarTreino() async {
    if (finalizando) return;

    setState(() {
      finalizando = true;
    });

    treinoTimer?.cancel();
    descansoTimer?.cancel();

    final agora = DateTime.now();
    final totalExercicios = exercicios.length;
    final concluidos = exerciciosConcluidos;
    final series = totalSeriesConcluidas;
    final volume = volumeTotalEstimado;
    final recordes = recordesBatidos;
    final calorias = caloriasEstimadas;
    final xp = xpGanho;

    await StorageService.salvarHistoricoTreino(
      HistoricoTreinoModel(
        id: "historico_${agora.microsecondsSinceEpoch}",
        nomeTreino: widget.treino.nome,
        dataHora: agora,
        tempoSegundos: segundos,
        tempoFormatado: tempoFormatado,
        exerciciosTotais: totalExercicios,
        exerciciosConcluidos: concluidos,
        xpGanho: xp,
        caloriasEstimadas: calorias,
        objetivo: widget.treino.objetivo,
        nivel: widget.treino.nivel,
        seriesConcluidas: series,
        volumeTotal: volume,
        recordesBatidos: recordes,
      ),
    );

    await StorageService.adicionarXp(xp);
    await widget.onXpAtualizado?.call();

    final conquistas = await const AchievementService().avaliarConquistas();

    if (!mounted) return;

    await _mostrarConquistasDesbloqueadas(conquistas.novas);

    if (!mounted) return;

    await Navigator.of(context).push<void>(
      MaterialPageRoute(
        builder: (_) => _ResumoTreinoProfissionalPage(
          nomeTreino: widget.treino.nome,
          tempoTotal: tempoFormatado,
          exercicios: "$concluidos/$totalExercicios",
          series: "$series",
          volume: "${_formatarNumero(volume)} kg",
          recordes: "$recordes",
          xp: "+$xp",
        ),
      ),
    );

    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  Future<void> _mostrarConquistasDesbloqueadas(
    List<AchievementModel> conquistas,
  ) async {
    if (conquistas.isEmpty || !mounted) return;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.surface,
          title: const Text("🏅 Nova conquista desbloqueada!"),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final conquista in conquistas)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: AppColors.rankOuro.withAlpha(36),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(
                            _achievementIcon(conquista.icone),
                            color: AppColors.rankOuro,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                conquista.nome,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                conquista.descricao,
                                style: const TextStyle(
                                  color: Colors.white70,
                                  height: 1.35,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Continuar"),
            ),
          ],
        );
      },
    );
  }

  String _textoMusculos(ExercicioModel exercicio) {
    final musculos = [...exercicio.musculos, ...exercicio.musculosSecundarios];
    if (musculos.isEmpty) return "Musculos nao cadastrados.";
    return musculos.take(5).join(" - ");
  }

  IconData _progressaoIcon(TipoProgressao tipo) {
    return switch (tipo) {
      TipoProgressao.progressao => Icons.arrow_upward_rounded,
      TipoProgressao.deload => Icons.arrow_downward_rounded,
      TipoProgressao.manutencao => Icons.trending_flat_rounded,
      TipoProgressao.inicial => Icons.auto_graph_rounded,
    };
  }

  Color _progressaoColor(TipoProgressao tipo) {
    return switch (tipo) {
      TipoProgressao.progressao => AppColors.primary,
      TipoProgressao.deload => AppColors.accent2,
      TipoProgressao.manutencao => AppColors.accent1,
      TipoProgressao.inicial => AppColors.accent3,
    };
  }

  String _progressaoLabel(TipoProgressao tipo) {
    return switch (tipo) {
      TipoProgressao.progressao => "Progressao",
      TipoProgressao.deload => "Deload",
      TipoProgressao.manutencao => "Manutencao",
      TipoProgressao.inicial => "Primeira referencia",
    };
  }

  String _recordeLabel(TipoRecorde tipo) {
    return switch (tipo) {
      TipoRecorde.carga => "Recorde de carga",
      TipoRecorde.repeticoes => "Recorde de reps",
      TipoRecorde.volume => "Recorde de volume",
    };
  }

  IconData _achievementIcon(String icone) {
    return switch (icone) {
      "fitness_center" => Icons.fitness_center_rounded,
      "format_list_numbered" => Icons.format_list_numbered_rounded,
      "monitor_weight" => Icons.monitor_weight_rounded,
      "local_fire_department" => Icons.local_fire_department_rounded,
      "timer" => Icons.timer_rounded,
      "emoji_events" => Icons.emoji_events_rounded,
      _ => Icons.workspace_premium_rounded,
    };
  }

  String _ultimaExecucaoTexto(ProgressaoSugestao sugestao) {
    final ultima = sugestao.ultimaExecucao;
    if (ultima == null) return "Sem execucao anterior";

    return "${_formatarNumero(ultima.peso)} kg x ${ultima.repeticoes} reps";
  }

  String _ultimaExecucaoData(ProgressaoSugestao sugestao) {
    final ultima = sugestao.ultimaExecucao;
    if (ultima == null) return "Conclua este exercicio para criar historico.";

    return "Data: ${_formatarData(ultima.dataHora)}";
  }

  String _sugestaoTexto(ProgressaoSugestao sugestao) {
    final carga = sugestao.cargaSugerida > 0
        ? "${_formatarNumero(sugestao.cargaSugerida)} kg"
        : "Carga livre";

    return "$carga x ${sugestao.repeticoesMin}-${sugestao.repeticoesMax} reps";
  }

  String _serieId(int exercicioIndex, int serieIndex) {
    if (exercicioIndex < 0 || exercicioIndex >= exercicios.length) {
      return "${sessaoTreinoId}_${exercicioIndex}_${serieIndex + 1}";
    }

    final exercicio = exercicios[exercicioIndex];
    final exercicioId = exercicio.id.trim().isEmpty
        ? exercicio.nome
        : exercicio.id;

    return "${sessaoTreinoId}_${exercicioIndex}_${exercicioId}_${serieIndex + 1}";
  }

  int _parseRepeticoes() {
    final valor = int.tryParse(repeticoesController.text.trim()) ?? 10;
    if (valor <= 0) return 10;
    if (valor > 999) return 999;
    return valor;
  }

  int _parseDescanso() {
    final valor =
        int.tryParse(descansoController.text.trim()) ?? _descansoPadrao;
    if (valor < 10) return 10;
    if (valor > 600) return 600;
    return valor;
  }

  double _parsePeso() {
    return double.tryParse(pesoController.text.trim().replaceAll(",", ".")) ??
        0;
  }

  String _formatarNumero(double valor) {
    if (valor == valor.roundToDouble()) return valor.round().toString();
    return valor.toStringAsFixed(1).replaceAll(".", ",");
  }

  String _formatarTempo(int totalSegundos) {
    final minutos = totalSegundos ~/ 60;
    final segundos = totalSegundos % 60;
    return "${minutos.toString().padLeft(2, "0")}:${segundos.toString().padLeft(2, "0")}";
  }

  String _formatarData(DateTime data) {
    final dia = data.day.toString().padLeft(2, "0");
    final mes = data.month.toString().padLeft(2, "0");
    final ano = data.year.toString();

    return "$dia/$mes/$ano";
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

class _ResumoTreinoProfissionalPage extends StatelessWidget {
  final String nomeTreino;
  final String tempoTotal;
  final String exercicios;
  final String series;
  final String volume;
  final String recordes;
  final String xp;

  const _ResumoTreinoProfissionalPage({
    required this.nomeTreino,
    required this.tempoTotal,
    required this.exercicios,
    required this.series,
    required this.volume,
    required this.recordes,
    required this.xp,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text("Resumo do treino"),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(
          _horizontalPadding(context),
          20,
          _horizontalPadding(context),
          28,
        ),
        children: [
          AppGradientCard(
            gradient: AppColors.gradientPrimary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.check_circle_rounded,
                  color: Colors.black,
                  size: 38,
                ),
                const SizedBox(height: 16),
                const Text(
                  "Treino salvo no histórico",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  nomeTreino,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppGradientCard(
            child: Column(
              children: [
                _resumoItem(Icons.timer_rounded, "Tempo total", tempoTotal),
                _resumoItem(
                  Icons.check_circle_rounded,
                  "Exercícios",
                  exercicios,
                ),
                _resumoItem(
                  Icons.format_list_numbered_rounded,
                  "Séries",
                  series,
                ),
                _resumoItem(Icons.monitor_weight_rounded, "Volume", volume),
                _resumoItem(
                  Icons.emoji_events_rounded,
                  "Recordes batidos",
                  recordes,
                ),
                _resumoItem(Icons.bolt_rounded, "XP", xp),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ElevatedButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.done_rounded),
            label: const Text("Concluir"),
          ),
        ],
      ),
    );
  }

  Widget _resumoItem(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: AppColors.surfaceVariant,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: AppColors.primary, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

class _SerieExecutada {
  final double peso;
  final int repeticoes;

  const _SerieExecutada({required this.peso, required this.repeticoes});

  double get volume => peso * repeticoes;
}

class _TreinoProfissionalVazio extends StatelessWidget {
  const _TreinoProfissionalVazio();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: AppEmptyState(
          icon: Icons.fitness_center_rounded,
          title: "Plano sem exercicios",
          message: "Adicione exercicios ao plano antes de iniciar.",
        ),
      ),
    );
  }
}
