import 'dart:async';

import 'package:flutter/material.dart';

import '../../data/exercicios/exercicios.dart';
import '../../models/exercicio_model.dart';
import '../../models/progresso_exercicio_model.dart';
import '../../models/treino_model.dart';
import '../../services/storage_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/exercicio_gif_viewer.dart';
import '../treinos/treinos_page.dart';

class _ExercicioBuscaIndex {
  final ExercicioModel exercicio;
  final String textoBusca;
  final String categoria;
  final Set<String> musculos;
  final Set<String> equipamentos;
  final Set<String> locais;

  const _ExercicioBuscaIndex({
    required this.exercicio,
    required this.textoBusca,
    required this.categoria,
    required this.musculos,
    required this.equipamentos,
    required this.locais,
  });
}

class _BibliotecaCategoria {
  final String nome;
  final List<String> aliases;
  final IconData icon;
  final Color color;

  const _BibliotecaCategoria({
    required this.nome,
    required this.aliases,
    required this.icon,
    required this.color,
  });
}

class BibliotecaExerciciosPage extends StatefulWidget {
  final void Function(ExercicioModel)? onSelecionar;
  final String? categoriaInicial;

  const BibliotecaExerciciosPage({
    super.key,
    this.onSelecionar,
    this.categoriaInicial,
  });

  @override
  State<BibliotecaExerciciosPage> createState() =>
      _BibliotecaExerciciosPageState();
}

class _BibliotecaExerciciosPageState extends State<BibliotecaExerciciosPage> {
  final pesquisaController = TextEditingController();

  static const categoriasPrincipais = [
    _BibliotecaCategoria(
      nome: "Peito",
      aliases: ["Peito"],
      icon: Icons.fitness_center_rounded,
      color: AppColors.primary,
    ),
    _BibliotecaCategoria(
      nome: "Costas",
      aliases: ["Costas"],
      icon: Icons.accessibility_new_rounded,
      color: AppColors.accent1,
    ),
    _BibliotecaCategoria(
      nome: "Pernas",
      aliases: ["Pernas"],
      icon: Icons.directions_walk_rounded,
      color: AppColors.accent2,
    ),
    _BibliotecaCategoria(
      nome: "Ombros",
      aliases: ["Ombros"],
      icon: Icons.expand_less_rounded,
      color: AppColors.accent3,
    ),
    _BibliotecaCategoria(
      nome: "Bracos",
      aliases: ["Biceps", "Triceps", "Antebraco"],
      icon: Icons.sports_martial_arts_rounded,
      color: Color(0xFF00BCD4),
    ),
    _BibliotecaCategoria(
      nome: "Abdomen",
      aliases: ["Abdomen"],
      icon: Icons.self_improvement_rounded,
      color: Color(0xFFFFD54F),
    ),
    _BibliotecaCategoria(
      nome: "Cardio",
      aliases: ["Cardio"],
      icon: Icons.directions_run_rounded,
      color: Color(0xFFFF6D00),
    ),
    _BibliotecaCategoria(
      nome: "Gluteos",
      aliases: ["Gluteos"],
      icon: Icons.local_fire_department_rounded,
      color: Color(0xFFEC407A),
    ),
  ];

  Timer? buscaDebounce;
  late final List<_ExercicioBuscaIndex> indiceBusca;
  late final Map<String, int> totaisPorCategoria;

  Set<String> favoritosIds = {};
  List<ExercicioModel> exerciciosFiltrados = [];
  String termoBusca = "";
  String termoBuscaNormalizado = "";
  String? categoriaSelecionada;
  String? localSelecionado;
  String? tipoEquipamentoSelecionado;
  String? dificuldadeSelecionada;
  bool apenasFavoritos = false;
  bool carregandoFavoritos = true;

  @override
  void initState() {
    super.initState();
    categoriaSelecionada = widget.categoriaInicial;
    indiceBusca = bancoExercicios.map(_criarIndice).toList(growable: false);
    totaisPorCategoria = _montarTotaisPorCategoria();
    exerciciosFiltrados = _filtrarExercicios();
    pesquisaController.addListener(_onBuscaAlterada);
    _carregarFavoritos();
  }

  @override
  void dispose() {
    buscaDebounce?.cancel();
    pesquisaController.removeListener(_onBuscaAlterada);
    pesquisaController.dispose();
    super.dispose();
  }

  void _onBuscaAlterada() {
    buscaDebounce?.cancel();
    buscaDebounce = Timer(const Duration(milliseconds: 300), () {
      if (!mounted) return;

      _atualizarFiltros(() {
        termoBusca = pesquisaController.text.trim();
        termoBuscaNormalizado = _normalizar(termoBusca);
      });
    });
  }

  Future<void> _carregarFavoritos() async {
    final favoritos = await StorageService.carregarFavoritosExercicios();

    if (!mounted) return;

    _sincronizarFavoritos(favoritos);

    setState(() {
      favoritosIds = favoritos;
      carregandoFavoritos = false;
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  void _sincronizarFavoritos(Set<String> favoritos) {
    for (final exercicio in bancoExercicios) {
      exercicio.favorito = favoritos.contains(exercicio.id);
    }
  }

  Future<void> _alternarFavorito(ExercicioModel exercicio) async {
    final favoritado = await StorageService.alternarFavoritoExercicio(
      exercicio.id,
    );
    final atualizados = {...favoritosIds};

    if (favoritado) {
      atualizados.add(exercicio.id);
    } else {
      atualizados.remove(exercicio.id);
    }

    _sincronizarFavoritos(atualizados);

    if (!mounted) return;

    setState(() {
      favoritosIds = atualizados;
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  void _atualizarFiltros(VoidCallback atualizar) {
    if (!mounted) return;

    setState(() {
      atualizar();
      exerciciosFiltrados = _filtrarExercicios();
    });
  }

  _ExercicioBuscaIndex _criarIndice(ExercicioModel exercicio) {
    return _ExercicioBuscaIndex(
      exercicio: exercicio,
      textoBusca: _textoBusca(exercicio),
      categoria: _normalizar(exercicio.categoria),
      musculos: _musculosDoExercicio(exercicio),
      equipamentos: _equipamentosDoExercicio(exercicio),
      locais: exercicio.locais.map(_normalizar).toSet(),
    );
  }

  List<ExercicioModel> _filtrarExercicios() {
    final busca = termoBuscaNormalizado;
    final categoria = categoriaSelecionada;
    final local = localSelecionado == null
        ? null
        : _normalizar(localSelecionado!);
    final tipoEquipamento = tipoEquipamentoSelecionado;
    final dificuldade = dificuldadeSelecionada == null
        ? null
        : _normalizar(dificuldadeSelecionada!);

    return indiceBusca
        .where((item) {
          if (!_pertenceCategoria(item, categoria)) {
            return false;
          }

          if (apenasFavoritos && !favoritosIds.contains(item.exercicio.id)) {
            return false;
          }

          if (local != null && !item.locais.contains(local)) {
            return false;
          }

          if (tipoEquipamento != null &&
              !_combinaTipoEquipamento(item, tipoEquipamento)) {
            return false;
          }

          if (dificuldade != null &&
              _normalizar(item.exercicio.dificuldade) != dificuldade) {
            return false;
          }

          if (busca.isEmpty) return true;

          return item.textoBusca.contains(busca);
        })
        .map((item) => item.exercicio)
        .toList(growable: false);
  }

  Map<String, int> _montarTotaisPorCategoria() {
    final totais = <String, int>{};

    for (final categoria in categoriasPrincipais) {
      totais[categoria.nome] = indiceBusca
          .where((item) => _pertenceCategoria(item, categoria.nome))
          .length;
    }

    return totais;
  }

  Future<void> _abrirDetalhe(ExercicioModel exercicio) async {
    final selecionado = await Navigator.push<ExercicioModel>(
      context,
      MaterialPageRoute(
        builder: (_) => BibliotecaExercicioDetalhePage(
          exercicio: exercicio,
          permitirSelecao: widget.onSelecionar != null,
        ),
      ),
    );

    await _carregarFavoritos();

    if (selecionado != null) {
      _selecionarExercicio(selecionado);
    }
  }

  void _selecionarExercicio(ExercicioModel exercicio) {
    final callback = widget.onSelecionar;
    if (callback == null) return;

    callback(exercicio);
    Navigator.pop(context);
  }

  void _limparFiltros() {
    buscaDebounce?.cancel();
    pesquisaController.removeListener(_onBuscaAlterada);
    pesquisaController.clear();
    pesquisaController.addListener(_onBuscaAlterada);

    _atualizarFiltros(() {
      termoBusca = "";
      termoBuscaNormalizado = "";
      localSelecionado = null;
      tipoEquipamentoSelecionado = null;
      dificuldadeSelecionada = null;
      apenasFavoritos = false;
    });
  }

  void _limparBusca() {
    buscaDebounce?.cancel();
    pesquisaController.removeListener(_onBuscaAlterada);
    pesquisaController.clear();
    pesquisaController.addListener(_onBuscaAlterada);

    _atualizarFiltros(() {
      termoBusca = "";
      termoBuscaNormalizado = "";
    });
  }

  void _abrirCategoria(String categoria) {
    _atualizarFiltros(() {
      categoriaSelecionada = categoria;
    });
  }

  void _voltarParaCategorias() {
    _atualizarFiltros(() {
      categoriaSelecionada = null;
      localSelecionado = null;
      tipoEquipamentoSelecionado = null;
      dificuldadeSelecionada = null;
      apenasFavoritos = false;
    });
  }

  bool get _temFiltroAtivo {
    return termoBusca.isNotEmpty ||
        apenasFavoritos ||
        localSelecionado != null ||
        tipoEquipamentoSelecionado != null ||
        dificuldadeSelecionada != null;
  }

  bool get _mostrandoResultados {
    return categoriaSelecionada != null || _temFiltroAtivo;
  }

  @override
  Widget build(BuildContext context) {
    final horizontal = _horizontalPadding(context);
    final titulo = categoriaSelecionada ?? "Biblioteca";

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(titulo),
        leading: categoriaSelecionada != null && widget.categoriaInicial == null
            ? IconButton(
                onPressed: _voltarParaCategorias,
                icon: const Icon(Icons.arrow_back_rounded),
                tooltip: "Voltar para categorias",
              )
            : null,
      ),
      body: RefreshIndicator(
        onRefresh: _carregarFavoritos,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(horizontal, 20, horizontal, 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildHero(),
                    const SizedBox(height: 18),
                    _buildBusca(),
                    if (!_mostrandoResultados) ...[
                      const SizedBox(height: 18),
                      _buildCategorias(),
                    ] else ...[
                      const SizedBox(height: 16),
                      _buildResumoCategoria(),
                      const SizedBox(height: 14),
                      _buildFiltros(),
                    ],
                  ],
                ),
              ),
            ),
            if (carregandoFavoritos)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: SliverToBoxAdapter(child: _loadingCard()),
              )
            else if (!_mostrandoResultados)
              const SliverToBoxAdapter(child: SizedBox(height: 32))
            else if (exerciciosFiltrados.isEmpty)
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: SliverToBoxAdapter(child: _estadoVazio()),
              )
            else
              SliverPadding(
                padding: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 32),
                sliver: _buildLista(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHero() {
    final totalTexto = _mostrandoResultados
        ? "${exerciciosFiltrados.length} encontrados"
        : "${bancoExercicios.length} exercicios";

    return AppGradientCard(
      gradient: AppColors.gradientPrimary,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: Colors.black.withAlpha(24),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(
              Icons.fitness_center_rounded,
              color: Colors.black,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "BIBLIOTECA",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  totalTexto,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 23,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  "Escolha uma categoria ou encontre rapidamente o movimento certo.",
                  style: TextStyle(
                    color: Colors.black87,
                    fontSize: 13,
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBusca() {
    return TextField(
      controller: pesquisaController,
      textInputAction: TextInputAction.search,
      decoration: InputDecoration(
        hintText: "Buscar por nome, musculo, tag ou equipamento",
        prefixIcon: const Icon(Icons.search_rounded),
        suffixIcon: termoBusca.isEmpty
            ? null
            : IconButton(
                onPressed: _limparBusca,
                icon: const Icon(Icons.close_rounded),
                tooltip: "Limpar busca",
              ),
      ),
    );
  }

  Widget _buildCategorias() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              "Categorias",
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const Spacer(),
            Text(
              "${categoriasPrincipais.length} grupos",
              style: const TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
        const SizedBox(height: 12),
        LayoutBuilder(
          builder: (context, constraints) {
            final colunas = constraints.maxWidth >= 920
                ? 4
                : constraints.maxWidth >= 620
                ? 3
                : 2;
            final spacing = 12.0;
            final largura =
                (constraints.maxWidth - spacing * (colunas - 1)) / colunas;

            return Wrap(
              spacing: spacing,
              runSpacing: spacing,
              children: categoriasPrincipais
                  .map((categoria) {
                    return SizedBox(
                      width: largura,
                      child: _categoriaCard(categoria),
                    );
                  })
                  .toList(growable: false),
            );
          },
        ),
        const SizedBox(height: 16),
        _buildAcessoRapido(),
      ],
    );
  }

  Widget _categoriaCard(_BibliotecaCategoria categoria) {
    final total = totaisPorCategoria[categoria.nome] ?? 0;

    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _abrirCategoria(categoria.nome),
      child: AppGradientCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: categoria.color.withAlpha(28),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(categoria.icon, color: categoria.color, size: 24),
            ),
            const SizedBox(height: 18),
            Text(
              categoria.nome,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              "$total exercicios",
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAcessoRapido() {
    return AppGradientCard(
      padding: const EdgeInsets.all(16),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _filterChip(
            label: "Favoritos",
            selected: apenasFavoritos,
            icon: Icons.star_rounded,
            onTap: () {
              _atualizarFiltros(() {
                apenasFavoritos = !apenasFavoritos;
              });
            },
          ),
          _filterChip(
            label: "Casa",
            selected: localSelecionado == "Casa",
            icon: Icons.home_rounded,
            onTap: () => _selecionarLocal("Casa"),
          ),
          _filterChip(
            label: "Academia",
            selected: localSelecionado == "Academia",
            icon: Icons.apartment_rounded,
            onTap: () => _selecionarLocal("Academia"),
          ),
        ],
      ),
    );
  }

  Widget _buildResumoCategoria() {
    final categoria = categoriaSelecionada;
    final texto = categoria == null
        ? "Resultados da busca"
        : "Categoria $categoria";

    return AppGradientCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.primary.withAlpha(28),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(
              Icons.inventory_2_rounded,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  texto,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "${exerciciosFiltrados.length} exercicios disponiveis",
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          if (categoriaSelecionada != null && widget.categoriaInicial == null)
            SizedBox(
              width: 40,
              height: 40,
              child: IconButton(
                onPressed: _voltarParaCategorias,
                tooltip: "Categorias",
                icon: const Icon(Icons.grid_view_rounded),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFiltros() {
    final filtrosAtivos = _temFiltroAtivo;

    return AppGradientCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.tune_rounded, color: AppColors.primary),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  "Filtros",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
              ),
              if (filtrosAtivos)
                TextButton(
                  onPressed: _limparFiltros,
                  child: const Text("Limpar"),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _filterChip(
                label: "Favoritos",
                selected: apenasFavoritos,
                icon: Icons.star_rounded,
                onTap: () {
                  _atualizarFiltros(() {
                    apenasFavoritos = !apenasFavoritos;
                  });
                },
              ),
              _filterChip(
                label: "Casa",
                selected: localSelecionado == "Casa",
                icon: Icons.home_rounded,
                onTap: () => _selecionarLocal("Casa"),
              ),
              _filterChip(
                label: "Academia",
                selected: localSelecionado == "Academia",
                icon: Icons.apartment_rounded,
                onTap: () => _selecionarLocal("Academia"),
              ),
              _filterChip(
                label: "Maquina",
                selected: tipoEquipamentoSelecionado == "Maquina",
                icon: Icons.precision_manufacturing_rounded,
                onTap: () => _selecionarTipoEquipamento("Maquina"),
              ),
              _filterChip(
                label: "Peso Livre",
                selected: tipoEquipamentoSelecionado == "Peso Livre",
                icon: Icons.fitness_center_rounded,
                onTap: () => _selecionarTipoEquipamento("Peso Livre"),
              ),
              _filterChip(
                label: "Iniciante",
                selected: dificuldadeSelecionada == "Iniciante",
                icon: Icons.looks_one_rounded,
                onTap: () => _selecionarDificuldade("Iniciante"),
              ),
              _filterChip(
                label: "Intermediario",
                selected: dificuldadeSelecionada == "Intermediario",
                icon: Icons.looks_two_rounded,
                onTap: () => _selecionarDificuldade("Intermediario"),
              ),
              _filterChip(
                label: "Avancado",
                selected: dificuldadeSelecionada == "Avancado",
                icon: Icons.workspace_premium_rounded,
                onTap: () => _selecionarDificuldade("Avancado"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _filterChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
    IconData? icon,
  }) {
    return ChoiceChip(
      selected: selected,
      avatar: icon == null
          ? null
          : Icon(
              icon,
              size: 16,
              color: selected ? Colors.black : Colors.white70,
            ),
      label: Text(label),
      onSelected: (_) => onTap(),
      selectedColor: AppColors.primary,
      backgroundColor: AppColors.surfaceVariant,
      labelStyle: TextStyle(
        color: selected ? Colors.black : Colors.white70,
        fontWeight: FontWeight.w700,
      ),
      side: BorderSide(
        color: selected ? AppColors.primary : const Color(0xFF2A2A2A),
      ),
    );
  }

  Widget _buildLista() {
    return SliverLayoutBuilder(
      builder: (context, constraints) {
        final colunas = constraints.crossAxisExtent >= 920 ? 2 : 1;
        final linhas = (exerciciosFiltrados.length / colunas).ceil();

        return SliverList.builder(
          itemCount: linhas,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _buildLinhaExercicio(index * colunas, colunas),
            );
          },
        );
      },
    );
  }

  Widget _buildLinhaExercicio(int inicio, int colunas) {
    final primeiro = _exercicioCard(exerciciosFiltrados[inicio]);

    if (colunas == 1) return primeiro;

    final segundoIndex = inicio + 1;
    final segundo = segundoIndex < exerciciosFiltrados.length
        ? _exercicioCard(exerciciosFiltrados[segundoIndex])
        : const SizedBox.shrink();

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(child: primeiro),
        const SizedBox(width: 12),
        Expanded(child: segundo),
      ],
    );
  }

  Widget _exercicioCard(ExercicioModel exercicio) {
    final favorito = favoritosIds.contains(exercicio.id);
    final equipamento = exercicio.equipamentos.isEmpty
        ? "Peso corporal"
        : exercicio.equipamentos.first;
    final locais = exercicio.locais.isEmpty
        ? "Local livre"
        : exercicio.locais.join(" / ");

    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => _abrirDetalhe(exercicio),
      child: AppGradientCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => mostrarGifExercicioTelaCheia(
                  context,
                  imagem: exercicio.imagem,
                  titulo: exercicio.nome,
                  subtitulo: exercicio.categoria,
                ),
                child: SizedBox(
                  height: 150,
                  width: double.infinity,
                  child: _imagemExercicio(exercicio),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(26),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Text(
                      exercicio.nome.isEmpty ? "?" : exercicio.nome[0],
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        exercicio.nome,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        "${exercicio.categoria} • ${exercicio.dificuldade}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  width: 38,
                  height: 38,
                  child: IconButton(
                    onPressed: () => _alternarFavorito(exercicio),
                    tooltip: favorito ? "Remover favorito" : "Favoritar",
                    icon: Icon(
                      favorito ? Icons.star_rounded : Icons.star_border_rounded,
                    ),
                    color: favorito ? AppColors.accent2 : Colors.white54,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _miniChip(equipamento),
                _miniChip(locais),
                if (exercicio.caloriasHora > 0)
                  _miniChip("${exercicio.caloriasHora} kcal/h"),
              ],
            ),
            if (exercicio.musculos.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(
                exercicio.musculos.take(3).join(" • "),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
            if (widget.onSelecionar != null) ...[
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: () => _selecionarExercicio(exercicio),
                icon: const Icon(Icons.add_rounded),
                label: const Text("Adicionar"),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _miniChip(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Text(
        texto,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _imagemExercicio(ExercicioModel exercicio) {
    final imagem = exercicio.imagem.trim();
    if (imagem.isEmpty) return _imagemFallback(exercicio);

    final network =
        imagem.startsWith("http://") || imagem.startsWith("https://");

    if (network) {
      return Container(
        color: Colors.black12,
        child: Image.network(
          imagem,
          fit: BoxFit.contain,
          filterQuality: FilterQuality.low,
          errorBuilder: (_, _, _) => _imagemFallback(exercicio),
        ),
      );
    }

    return Container(
      color: Colors.black12,
      child: Image.asset(
        imagem,
        fit: BoxFit.contain,
        cacheWidth: 640,
        filterQuality: FilterQuality.low,
        semanticLabel: exercicio.nome,
        errorBuilder: (_, _, _) => _imagemFallback(exercicio),
      ),
    );
  }

  Widget _imagemFallback(ExercicioModel exercicio) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary.withAlpha(55), AppColors.surfaceVariant],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.fitness_center_rounded,
              color: AppColors.primary,
              size: 34,
            ),
            const SizedBox(height: 8),
            Text(
              exercicio.categoria,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _estadoVazio() {
    return AppEmptyState(
      icon: Icons.search_off_rounded,
      title: "Nenhum exercicio encontrado",
      message:
          "Ajuste a busca ou remova alguns filtros para ampliar os resultados.",
      action: OutlinedButton.icon(
        onPressed: _limparFiltros,
        icon: const Icon(Icons.refresh_rounded),
        label: const Text("Limpar filtros"),
      ),
    );
  }

  Widget _loadingCard() {
    return const AppLoadingCard(message: "Carregando biblioteca...");
  }

  void _selecionarLocal(String local) {
    _atualizarFiltros(() {
      localSelecionado = localSelecionado == local ? null : local;
    });
  }

  void _selecionarTipoEquipamento(String tipo) {
    _atualizarFiltros(() {
      tipoEquipamentoSelecionado = tipoEquipamentoSelecionado == tipo
          ? null
          : tipo;
    });
  }

  void _selecionarDificuldade(String dificuldade) {
    _atualizarFiltros(() {
      dificuldadeSelecionada = dificuldadeSelecionada == dificuldade
          ? null
          : dificuldade;
    });
  }

  bool _pertenceCategoria(_ExercicioBuscaIndex item, String? categoria) {
    if (categoria == null) return true;

    final config = _categoriaPorNome(categoria);
    final aliases = config?.aliases ?? [categoria];

    for (final alias in aliases.map(_normalizar)) {
      if (item.categoria == alias) return true;
      if (item.musculos.contains(alias)) return true;
    }

    return false;
  }

  _BibliotecaCategoria? _categoriaPorNome(String nome) {
    final normalizado = _normalizar(nome);

    for (final categoria in categoriasPrincipais) {
      if (_normalizar(categoria.nome) == normalizado) return categoria;
    }

    return null;
  }

  bool _combinaTipoEquipamento(_ExercicioBuscaIndex item, String tipo) {
    if (tipo == "Maquina") return _usaMaquina(item.equipamentos);
    if (tipo == "Peso Livre") return _usaPesoLivre(item.equipamentos);
    return true;
  }

  bool _usaMaquina(Set<String> equipamentos) {
    const termos = [
      "maquina",
      "polia",
      "cabo",
      "cabos",
      "smith",
      "cadeira",
      "leg press",
      "hack",
      "cross",
    ];

    return equipamentos.any(
      (equipamento) => termos.any((termo) => equipamento.contains(termo)),
    );
  }

  bool _usaPesoLivre(Set<String> equipamentos) {
    const termos = [
      "halter",
      "halteres",
      "barra",
      "anilha",
      "anilhas",
      "kettlebell",
      "peso corporal",
      "elastico",
      "faixa",
    ];

    return equipamentos.any(
      (equipamento) => termos.any((termo) => equipamento.contains(termo)),
    );
  }

  Set<String> _musculosDoExercicio(ExercicioModel exercicio) {
    return {
      ...exercicio.musculos.map(_normalizar),
      ...exercicio.musculosSecundarios.map(_normalizar),
    };
  }

  Set<String> _equipamentosDoExercicio(ExercicioModel exercicio) {
    if (exercicio.equipamentos.isEmpty) {
      return {_normalizar("Peso corporal")};
    }

    return exercicio.equipamentos.map(_normalizar).toSet();
  }

  String _textoBusca(ExercicioModel exercicio) {
    return [
      exercicio.nome,
      exercicio.categoria,
      exercicio.descricao,
      exercicio.comoExecutar,
      exercicio.dificuldade,
      exercicio.objetivo,
      ...exercicio.musculos,
      ...exercicio.musculosSecundarios,
      ...exercicio.equipamentos,
      ...exercicio.locais,
      ...exercicio.tags,
    ].map(_normalizar).join(" ");
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

class BibliotecaExercicioDetalhePage extends StatefulWidget {
  final ExercicioModel exercicio;
  final bool permitirSelecao;

  const BibliotecaExercicioDetalhePage({
    super.key,
    required this.exercicio,
    this.permitirSelecao = false,
  });

  @override
  State<BibliotecaExercicioDetalhePage> createState() =>
      _BibliotecaExercicioDetalhePageState();
}

class _BibliotecaExercicioDetalhePageState
    extends State<BibliotecaExercicioDetalhePage> {
  bool favorito = false;
  bool carregandoFavorito = true;
  late final Future<List<ProgressoExercicioModel>> progressoFuture;

  ExercicioModel get exercicio => widget.exercicio;

  @override
  void initState() {
    super.initState();
    progressoFuture = StorageService.carregarHistoricoExercicio(exercicio.nome);
    _carregarFavorito();
  }

  Future<void> _carregarFavorito() async {
    final favoritos = await StorageService.carregarFavoritosExercicios();

    if (!mounted) return;

    setState(() {
      favorito = favoritos.contains(exercicio.id);
      exercicio.favorito = favorito;
      carregandoFavorito = false;
    });
  }

  Future<void> _alternarFavorito() async {
    final novoEstado = await StorageService.alternarFavoritoExercicio(
      exercicio.id,
    );

    if (!mounted) return;

    setState(() {
      favorito = novoEstado;
      exercicio.favorito = novoEstado;
    });
  }

  List<ExercicioModel> get semelhantes {
    final candidatos = bancoExercicios.where((item) {
      if (item.id == exercicio.id) return false;

      return _scoreSemelhanca(item) > 0;
    }).toList();

    candidatos.sort(
      (a, b) => _scoreSemelhanca(b).compareTo(_scoreSemelhanca(a)),
    );

    return candidatos.take(6).toList();
  }

  int _scoreSemelhanca(ExercicioModel candidato) {
    var score = 0;

    if (_normalizar(candidato.categoria) == _normalizar(exercicio.categoria)) {
      score += 3;
    }

    score += _intersecoes(
      _musculosDoExercicio(candidato),
      _musculosDoExercicio(exercicio),
    );

    score += _intersecoes(
      candidato.equipamentos.map(_normalizar).toSet(),
      exercicio.equipamentos.map(_normalizar).toSet(),
    );

    return score;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: Text(exercicio.nome)),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.fromLTRB(
          _horizontalPadding(context),
          20,
          _horizontalPadding(context),
          32,
        ),
        children: [
          _imagemHero(),
          const SizedBox(height: 16),
          _topoDetalhe(),
          const SizedBox(height: 16),
          _acoes(),
          const SizedBox(height: 16),
          _progressoCard(),
          const SizedBox(height: 16),
          _secaoTexto(
            titulo: "Descricao",
            texto: exercicio.descricao.isEmpty
                ? "Descricao ainda nao cadastrada."
                : exercicio.descricao,
            icon: Icons.notes_rounded,
          ),
          _secaoTexto(
            titulo: "Como executar",
            texto: exercicio.comoExecutar.isEmpty
                ? "Instrucoes ainda nao cadastradas."
                : exercicio.comoExecutar,
            icon: Icons.playlist_add_check_rounded,
          ),
          _passosCard(),
          _secaoTexto(
            titulo: "Cuidados",
            texto: exercicio.cuidados.isEmpty
                ? "Cuidados especificos ainda nao cadastrados."
                : exercicio.cuidados,
            icon: Icons.health_and_safety_rounded,
          ),
          _chips(
            titulo: "Grupo muscular",
            itens: [_grupoMuscularPrincipal()],
            vazio: "Grupo muscular nao cadastrado.",
            icon: Icons.accessibility_new_rounded,
          ),
          _chips(
            titulo: "Equipamentos",
            itens: exercicio.equipamentos.isEmpty
                ? const ["Peso corporal"]
                : exercicio.equipamentos,
            vazio: "Equipamentos nao cadastrados.",
            icon: Icons.fitness_center_rounded,
          ),
          _chips(
            titulo: "Musculos",
            itens: [...exercicio.musculos, ...exercicio.musculosSecundarios],
            vazio: "Musculos nao cadastrados.",
            icon: Icons.hub_rounded,
          ),
          _chips(
            titulo: "Tags",
            itens: exercicio.tags,
            vazio: "Tags ainda nao cadastradas.",
            icon: Icons.sell_rounded,
          ),
          _chips(
            titulo: "Dificuldade e locais",
            itens: [
              exercicio.dificuldade,
              exercicio.objetivo,
              ...exercicio.locais,
            ],
            vazio: "Dados adicionais nao cadastrados.",
            icon: Icons.tune_rounded,
          ),
          _semelhantesCard(),
        ],
      ),
    );
  }

  Widget _imagemHero() {
    final imagem = exercicio.imagem.trim();

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => mostrarGifExercicioTelaCheia(
        context,
        imagem: exercicio.imagem,
        titulo: exercicio.nome,
        subtitulo: exercicio.categoria,
      ),
      child: AppGradientCard(
        padding: EdgeInsets.zero,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 220, minHeight: 160),
            child: SizedBox(
              height: 200,
              width: double.infinity,
              child: imagem.isEmpty
                  ? _imagemFallbackDetalhe()
                  : _imagemDetalhe(imagem),
            ),
          ),
        ),
      ),
    );
  }

  Widget _imagemDetalhe(String imagem) {
    final network =
        imagem.startsWith("http://") || imagem.startsWith("https://");

    if (network) {
      return Image.network(
        imagem,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.low,
        errorBuilder: (_, _, _) => _imagemFallbackDetalhe(),
      );
    }

    return Image.asset(
      imagem,
      fit: BoxFit.contain,
      cacheWidth: 900,
      filterQuality: FilterQuality.low,
      semanticLabel: exercicio.nome,
      errorBuilder: (_, _, _) => _imagemFallbackDetalhe(),
    );
  }

  Widget _imagemFallbackDetalhe() {
    return Container(
      decoration: const BoxDecoration(gradient: AppColors.gradientWorkout),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.fitness_center_rounded,
              color: Colors.white,
              size: 52,
            ),
            const SizedBox(height: 10),
            Text(
              exercicio.categoria,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topoDetalhe() {
    return AppGradientCard(
      gradient: AppColors.gradientPrimary,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              color: Colors.black.withAlpha(24),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Text(
                exercicio.nome.isEmpty ? "?" : exercicio.nome[0],
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "DETALHE DO EXERCICIO",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  exercicio.nome,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _grupoMuscularPrincipal(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _topoChip(exercicio.categoria),
                    _topoChip(exercicio.dificuldade),
                    if (exercicio.caloriasHora > 0)
                      _topoChip("${exercicio.caloriasHora} kcal/h"),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _acoes() {
    final favoritoLabel = favorito ? "Remover favorito" : "Favoritar";

    return LayoutBuilder(
      builder: (context, constraints) {
        final ladoALado = constraints.maxWidth >= 620;
        final favoritoButton = OutlinedButton.icon(
          onPressed: carregandoFavorito ? null : _alternarFavorito,
          icon: Icon(favorito ? Icons.star_rounded : Icons.star_border_rounded),
          label: Text(favoritoLabel),
        );
        final executarButton = ElevatedButton.icon(
          onPressed: _executarAgora,
          icon: const Icon(Icons.play_arrow_rounded),
          label: const Text("Executar Agora"),
        );
        final voltarButton = OutlinedButton.icon(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_rounded),
          label: const Text("Voltar"),
        );
        final adicionarButton = ElevatedButton.icon(
          onPressed: () => Navigator.pop(context, exercicio),
          icon: const Icon(Icons.add_rounded),
          label: const Text("Adicionar a ficha"),
        );

        if (widget.permitirSelecao) {
          return Column(
            children: [
              adicionarButton,
              const SizedBox(height: 10),
              executarButton,
              const SizedBox(height: 10),
              if (ladoALado)
                Row(
                  children: [
                    Expanded(child: favoritoButton),
                    const SizedBox(width: 10),
                    Expanded(child: voltarButton),
                  ],
                )
              else ...[
                favoritoButton,
                const SizedBox(height: 10),
                voltarButton,
              ],
            ],
          );
        }

        if (!ladoALado) {
          return Column(
            children: [
              executarButton,
              const SizedBox(height: 10),
              favoritoButton,
              const SizedBox(height: 10),
              voltarButton,
            ],
          );
        }

        return Column(
          children: [
            executarButton,
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: favoritoButton),
                const SizedBox(width: 10),
                Expanded(child: voltarButton),
              ],
            ),
          ],
        );
      },
    );
  }

  Future<void> _executarAgora() async {
    final agora = DateTime.now();

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TreinoEmAndamentoPage(
          treino: TreinoModel(
            id: "execucao_${exercicio.id}_${agora.microsecondsSinceEpoch}",
            nome: "Treino rapido - ${exercicio.nome}",
            descricao: "Execucao rapida criada pela Biblioteca de Exercicios.",
            objetivo: exercicio.objetivo,
            nivel: exercicio.dificuldade,
            tempoEstimado: 8,
            criadoPorIA: false,
            exercicios: [exercicio],
            dataCriacao: agora.toIso8601String(),
          ),
        ),
      ),
    );
  }

  Widget _progressoCard() {
    return FutureBuilder<List<ProgressoExercicioModel>>(
      future: progressoFuture,
      builder: (context, snapshot) {
        final historico = snapshot.data ?? const <ProgressoExercicioModel>[];

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const AppLoadingCard(message: "Carregando progressao...");
        }

        if (historico.isEmpty) {
          return AppGradientCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _secaoTitulo("Progressao de carga", Icons.trending_up_rounded),
                const SizedBox(height: 12),
                const AppInfoRow(
                  icon: Icons.history_rounded,
                  label: "Ultima carga registrada",
                  value: "Sem registro",
                  color: AppColors.accent1,
                ),
                const SizedBox(height: 12),
                const AppInfoRow(
                  icon: Icons.emoji_events_rounded,
                  label: "Recorde pessoal",
                  value: "Sem registro",
                  color: AppColors.accent2,
                ),
              ],
            ),
          );
        }

        final ultimo = historico.first;
        final recorde = historico.reduce(
          (atual, item) => item.peso > atual.peso ? item : atual,
        );

        return AppGradientCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _secaoTitulo("Progressao de carga", Icons.trending_up_rounded),
              const SizedBox(height: 12),
              AppInfoRow(
                icon: Icons.history_rounded,
                label: "Ultima carga registrada",
                value:
                    "${_formatarPeso(ultimo.peso)} kg • ${ultimo.series}x${ultimo.repeticoes}",
                color: AppColors.accent1,
              ),
              const SizedBox(height: 12),
              AppInfoRow(
                icon: Icons.emoji_events_rounded,
                label: "Recorde pessoal",
                value:
                    "${_formatarPeso(recorde.peso)} kg • ${_formatarDataCurta(recorde.data)}",
                color: AppColors.accent2,
              ),
              const SizedBox(height: 12),
              AppInfoRow(
                icon: Icons.trending_up_rounded,
                label: "Evolucao recente",
                value: _textoEvolucao(historico),
                color: AppColors.primary,
              ),
            ],
          ),
        );
      },
    );
  }

  String _textoEvolucao(List<ProgressoExercicioModel> historico) {
    if (historico.length < 2) return "Primeiro registro";

    final atual = historico[0].peso;
    final anterior = historico[1].peso;
    final diferenca = atual - anterior;

    if (diferenca > 0) return "+${_formatarPeso(diferenca)} kg";
    if (diferenca < 0) return "${_formatarPeso(diferenca)} kg";

    return "Carga mantida";
  }

  String _formatarPeso(double peso) {
    if (peso == peso.roundToDouble()) return peso.round().toString();
    return peso.toStringAsFixed(1).replaceAll(".", ",");
  }

  String _formatarDataCurta(DateTime data) {
    final dia = data.day.toString().padLeft(2, "0");
    final mes = data.month.toString().padLeft(2, "0");

    return "$dia/$mes";
  }

  Widget _secaoTexto({
    required String titulo,
    required String texto,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AppGradientCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _secaoTitulo(titulo, icon),
            const SizedBox(height: 12),
            Text(
              texto,
              style: const TextStyle(color: Colors.white70, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }

  Widget _passosCard() {
    final passos = _passosExecucao();

    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AppGradientCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _secaoTitulo("Passo a passo", Icons.format_list_numbered_rounded),
            const SizedBox(height: 14),
            for (var i = 0; i < passos.length; i++) ...[
              _passoItem(numero: i + 1, texto: passos[i]),
              if (i < passos.length - 1) const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }

  Widget _passoItem({required int numero, required String texto}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: AppColors.primary.withAlpha(28),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primary.withAlpha(90)),
          ),
          child: Center(
            child: Text(
              "$numero",
              style: const TextStyle(
                color: AppColors.primary,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Passo $numero",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                texto,
                style: const TextStyle(color: Colors.white70, height: 1.4),
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<String> _passosExecucao() {
    final partes = exercicio.comoExecutar
        .split(RegExp(r"[\n.;]+"))
        .map((item) => item.trim())
        .where((item) => item.length > 8)
        .toList();
    final fallback = [
      "Ajuste a postura inicial e prepare a amplitude do movimento.",
      "Execute o movimento de forma controlada, sem perder alinhamento.",
      "Retorne devagar a posicao inicial, mantendo tensao no musculo alvo.",
      "Respire de forma constante e pare se sentir dor articular.",
    ];

    return List.generate(4, (index) {
      if (index < partes.length) return partes[index];
      return fallback[index];
    });
  }

  String _grupoMuscularPrincipal() {
    if (exercicio.musculos.isNotEmpty) {
      return exercicio.musculos.take(2).join(" / ");
    }

    return exercicio.categoria;
  }

  Widget _chips({
    required String titulo,
    required List<String> itens,
    required String vazio,
    required IconData icon,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: AppGradientCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _secaoTitulo(titulo, icon),
            const SizedBox(height: 12),
            if (itens.isEmpty)
              Text(
                vazio,
                style: const TextStyle(color: Colors.white70, height: 1.4),
              )
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: itens.map(_chipEscuro).toList(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _semelhantesCard() {
    final lista = semelhantes;

    return AppGradientCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _secaoTitulo("Exercicios semelhantes", Icons.auto_awesome_rounded),
          const SizedBox(height: 12),
          if (lista.isEmpty)
            const Text(
              "Nenhum exercicio semelhante encontrado.",
              style: TextStyle(color: Colors.white70),
            )
          else
            Column(
              children: lista.map((item) {
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceVariant,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF2A2A2A)),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.fitness_center_rounded,
                        color: AppColors.primary,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item.nome,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              "${item.categoria} • ${item.dificuldade}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _secaoTitulo(String titulo, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primary, size: 18),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            titulo.toUpperCase(),
            style: const TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
      ],
    );
  }

  Widget _chipEscuro(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.surfaceVariant,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF2A2A2A)),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  Widget _topoChip(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(24),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: Colors.black87,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Set<String> _musculosDoExercicio(ExercicioModel exercicio) {
    return {
      ...exercicio.musculos.map(_normalizar),
      ...exercicio.musculosSecundarios.map(_normalizar),
    };
  }

  int _intersecoes(Set<String> a, Set<String> b) {
    return a.where(b.contains).length;
  }

  double _horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 1100) return 72;
    if (width >= 760) return 36;
    return 20;
  }
}

String _normalizar(String texto) {
  var valor = texto.toLowerCase().trim();
  final substituicoes = {
    "\u00e1": "a",
    "\u00e0": "a",
    "\u00e2": "a",
    "\u00e3": "a",
    "\u00e4": "a",
    "\u00e9": "e",
    "\u00ea": "e",
    "\u00e8": "e",
    "\u00eb": "e",
    "\u00ed": "i",
    "\u00ec": "i",
    "\u00ee": "i",
    "\u00ef": "i",
    "\u00f3": "o",
    "\u00f2": "o",
    "\u00f4": "o",
    "\u00f5": "o",
    "\u00f6": "o",
    "\u00fa": "u",
    "\u00f9": "u",
    "\u00fb": "u",
    "\u00fc": "u",
    "\u00e7": "c",
  };

  for (final entrada in substituicoes.entries) {
    valor = valor.replaceAll(entrada.key, entrada.value);
  }

  return valor;
}
